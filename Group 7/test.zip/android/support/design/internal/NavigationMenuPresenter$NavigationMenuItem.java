package android.support.design.internal;

interface NavigationMenuPresenter$NavigationMenuItem {
}
