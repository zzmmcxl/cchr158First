package android.support.design.internal;

import android.support.v7.widget.RecyclerView$ViewHolder;
import android.view.View;

abstract class NavigationMenuPresenter$ViewHolder extends RecyclerView$ViewHolder {
   public NavigationMenuPresenter$ViewHolder(View var1) {
      super(var1);
   }
}
