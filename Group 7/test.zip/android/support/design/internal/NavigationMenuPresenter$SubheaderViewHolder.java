package android.support.design.internal;

import android.support.design.R$layout;
import android.support.design.internal.NavigationMenuPresenter$ViewHolder;
import android.view.LayoutInflater;
import android.view.ViewGroup;

class NavigationMenuPresenter$SubheaderViewHolder extends NavigationMenuPresenter$ViewHolder {
   public NavigationMenuPresenter$SubheaderViewHolder(LayoutInflater var1, ViewGroup var2) {
      super(var1.inflate(R$layout.design_navigation_item_subheader, var2, false));
   }
}
