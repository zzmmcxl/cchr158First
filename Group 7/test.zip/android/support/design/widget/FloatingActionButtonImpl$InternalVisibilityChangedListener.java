package android.support.design.widget;

interface FloatingActionButtonImpl$InternalVisibilityChangedListener {
   void onHidden();

   void onShown();
}
