package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.design.widget.TextInputLayout$SavedState;

final class TextInputLayout$SavedState$1 implements Creator<TextInputLayout$SavedState> {
   public TextInputLayout$SavedState createFromParcel(Parcel var1) {
      return new TextInputLayout$SavedState(var1);
   }

   public TextInputLayout$SavedState[] newArray(int var1) {
      return new TextInputLayout$SavedState[var1];
   }
}
