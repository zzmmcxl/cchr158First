package android.support.design.widget;

interface ValueAnimatorCompat$Impl$AnimatorListenerProxy {
   void onAnimationCancel();

   void onAnimationEnd();

   void onAnimationStart();
}
