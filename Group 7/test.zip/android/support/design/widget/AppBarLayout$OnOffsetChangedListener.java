package android.support.design.widget;

import android.support.design.widget.AppBarLayout;

public interface AppBarLayout$OnOffsetChangedListener {
   void onOffsetChanged(AppBarLayout var1, int var2);
}
