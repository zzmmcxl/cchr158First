package android.support.design.widget;

import android.support.design.widget.ValueAnimatorCompat;
import android.support.design.widget.ValueAnimatorCompat$AnimatorListener;

class ValueAnimatorCompat$AnimatorListenerAdapter implements ValueAnimatorCompat$AnimatorListener {
   public void onAnimationCancel(ValueAnimatorCompat var1) {
   }

   public void onAnimationEnd(ValueAnimatorCompat var1) {
   }

   public void onAnimationStart(ValueAnimatorCompat var1) {
   }
}
