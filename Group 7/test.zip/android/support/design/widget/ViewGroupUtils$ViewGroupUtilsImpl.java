package android.support.design.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

interface ViewGroupUtils$ViewGroupUtilsImpl {
   void offsetDescendantRect(ViewGroup var1, View var2, Rect var3);
}
