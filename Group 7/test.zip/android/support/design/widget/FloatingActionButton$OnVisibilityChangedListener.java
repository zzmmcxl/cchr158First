package android.support.design.widget;

import android.support.design.widget.FloatingActionButton;

public abstract class FloatingActionButton$OnVisibilityChangedListener {
   public void onHidden(FloatingActionButton var1) {
   }

   public void onShown(FloatingActionButton var1) {
   }
}
