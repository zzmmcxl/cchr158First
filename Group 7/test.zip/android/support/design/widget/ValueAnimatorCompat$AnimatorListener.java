package android.support.design.widget;

import android.support.design.widget.ValueAnimatorCompat;

interface ValueAnimatorCompat$AnimatorListener {
   void onAnimationCancel(ValueAnimatorCompat var1);

   void onAnimationEnd(ValueAnimatorCompat var1);

   void onAnimationStart(ValueAnimatorCompat var1);
}
