package android.support.design.widget;

import android.support.design.widget.ValueAnimatorCompat;

interface ValueAnimatorCompat$AnimatorUpdateListener {
   void onAnimationUpdate(ValueAnimatorCompat var1);
}
