package android.support.design.widget;

import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;

public abstract class AppBarLayout$Behavior$DragCallback {
   public abstract boolean canDrag(@NonNull AppBarLayout var1);
}
