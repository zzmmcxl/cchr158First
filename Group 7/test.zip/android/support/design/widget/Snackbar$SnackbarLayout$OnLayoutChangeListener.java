package android.support.design.widget;

import android.view.View;

interface Snackbar$SnackbarLayout$OnLayoutChangeListener {
   void onLayoutChange(View var1, int var2, int var3, int var4, int var5);
}
