package android.support.v4.widget;

import android.support.v4.widget.DrawerLayout$DrawerListener;
import android.view.View;

public abstract class DrawerLayout$SimpleDrawerListener implements DrawerLayout$DrawerListener {
   public void onDrawerClosed(View var1) {
   }

   public void onDrawerOpened(View var1) {
   }

   public void onDrawerSlide(View var1, float var2) {
   }

   public void onDrawerStateChanged(int var1) {
   }
}
