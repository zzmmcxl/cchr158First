package android.support.v4.widget;

import android.support.v4.widget.SearchViewCompat;

public abstract class SearchViewCompat$OnQueryTextListenerCompat {
   final Object mListener = SearchViewCompat.access$000().newOnQueryTextListener(this);

   public boolean onQueryTextChange(String var1) {
      return false;
   }

   public boolean onQueryTextSubmit(String var1) {
      return false;
   }
}
