package android.support.v4.widget;

interface SearchViewCompatHoneycomb$OnCloseListenerCompatBridge {
   boolean onClose();
}
