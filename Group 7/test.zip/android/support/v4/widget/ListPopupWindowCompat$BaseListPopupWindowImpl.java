package android.support.v4.widget;

import android.support.v4.widget.ListPopupWindowCompat$ListPopupWindowImpl;
import android.view.View;
import android.view.View.OnTouchListener;

class ListPopupWindowCompat$BaseListPopupWindowImpl implements ListPopupWindowCompat$ListPopupWindowImpl {
   public OnTouchListener createDragToOpenListener(Object var1, View var2) {
      return null;
   }
}
