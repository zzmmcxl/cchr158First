package android.support.v4.widget;

// $FF: synthetic class
class AutoScrollHelper$1 {
}
