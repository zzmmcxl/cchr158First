package android.support.v4.widget;

import android.view.View;

public interface DrawerLayout$DrawerListener {
   void onDrawerClosed(View var1);

   void onDrawerOpened(View var1);

   void onDrawerSlide(View var1, float var2);

   void onDrawerStateChanged(int var1);
}
