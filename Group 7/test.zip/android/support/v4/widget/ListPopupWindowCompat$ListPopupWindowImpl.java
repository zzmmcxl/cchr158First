package android.support.v4.widget;

import android.view.View;
import android.view.View.OnTouchListener;

interface ListPopupWindowCompat$ListPopupWindowImpl {
   OnTouchListener createDragToOpenListener(Object var1, View var2);
}
