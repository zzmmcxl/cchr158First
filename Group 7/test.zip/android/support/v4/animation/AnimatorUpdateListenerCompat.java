package android.support.v4.animation;

import android.support.v4.animation.ValueAnimatorCompat;

public interface AnimatorUpdateListenerCompat {
   void onAnimationUpdate(ValueAnimatorCompat var1);
}
