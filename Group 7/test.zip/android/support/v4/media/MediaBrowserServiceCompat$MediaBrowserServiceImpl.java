package android.support.v4.media;

import android.content.Intent;
import android.os.IBinder;

interface MediaBrowserServiceCompat$MediaBrowserServiceImpl {
   IBinder onBind(Intent var1);

   void onCreate();
}
