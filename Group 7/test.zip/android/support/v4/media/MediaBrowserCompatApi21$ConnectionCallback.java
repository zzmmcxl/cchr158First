package android.support.v4.media;

interface MediaBrowserCompatApi21$ConnectionCallback {
   void onConnected();

   void onConnectionFailed();

   void onConnectionSuspended();
}
