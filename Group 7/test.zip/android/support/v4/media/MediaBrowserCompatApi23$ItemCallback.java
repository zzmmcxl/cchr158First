package android.support.v4.media;

import android.os.Parcel;
import android.support.annotation.NonNull;

interface MediaBrowserCompatApi23$ItemCallback {
   void onError(@NonNull String var1);

   void onItemLoaded(Parcel var1);
}
