package android.support.v4.media;

public interface VolumeProviderCompatApi21$Delegate {
   void onAdjustVolume(int var1);

   void onSetVolumeTo(int var1);
}
