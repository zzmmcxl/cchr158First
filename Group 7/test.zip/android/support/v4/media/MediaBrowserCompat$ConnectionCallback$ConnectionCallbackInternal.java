package android.support.v4.media;

interface MediaBrowserCompat$ConnectionCallback$ConnectionCallbackInternal {
   void onConnected();

   void onConnectionFailed();

   void onConnectionSuspended();
}
