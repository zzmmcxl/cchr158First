package android.support.v4.media.session;

import android.support.v4.media.session.MediaSessionCompatApi18$Callback;

interface MediaSessionCompatApi19$Callback extends MediaSessionCompatApi18$Callback {
   void onSetRating(Object var1);
}
