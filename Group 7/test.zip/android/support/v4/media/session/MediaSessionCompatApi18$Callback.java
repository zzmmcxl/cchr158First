package android.support.v4.media.session;

interface MediaSessionCompatApi18$Callback {
   void onSeekTo(long var1);
}
