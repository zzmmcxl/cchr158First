package android.support.v4.text;

interface TextDirectionHeuristicsCompat$TextDirectionAlgorithm {
   int checkRtl(CharSequence var1, int var2, int var3);
}
