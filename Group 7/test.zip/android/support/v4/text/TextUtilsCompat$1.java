package android.support.v4.text;

// $FF: synthetic class
class TextUtilsCompat$1 {
}
