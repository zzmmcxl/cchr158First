package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.app.RemoteInputCompatBase$RemoteInput;

public interface RemoteInputCompatBase$RemoteInput$Factory {
   RemoteInputCompatBase$RemoteInput build(String var1, CharSequence var2, CharSequence[] var3, boolean var4, Bundle var5);

   RemoteInputCompatBase$RemoteInput[] newArray(int var1);
}
