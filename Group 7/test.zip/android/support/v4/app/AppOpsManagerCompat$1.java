package android.support.v4.app;

// $FF: synthetic class
class AppOpsManagerCompat$1 {
}
