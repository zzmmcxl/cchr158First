package android.support.v4.app;

import android.support.v4.app.NotificationCompat$Action$Builder;

public interface NotificationCompat$Action$Extender {
   NotificationCompat$Action$Builder extend(NotificationCompat$Action$Builder var1);
}
