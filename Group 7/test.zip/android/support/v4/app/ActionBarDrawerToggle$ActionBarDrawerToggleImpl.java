package android.support.v4.app;

import android.app.Activity;
import android.graphics.drawable.Drawable;

interface ActionBarDrawerToggle$ActionBarDrawerToggleImpl {
   Drawable getThemeUpIndicator(Activity var1);

   Object setActionBarDescription(Object var1, Activity var2, int var3);

   Object setActionBarUpIndicator(Object var1, Activity var2, Drawable var3, int var4);
}
