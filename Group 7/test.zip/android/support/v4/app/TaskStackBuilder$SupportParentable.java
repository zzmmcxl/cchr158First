package android.support.v4.app;

import android.content.Intent;

public interface TaskStackBuilder$SupportParentable {
   Intent getSupportParentActivityIntent();
}
