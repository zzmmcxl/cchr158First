package android.support.v4.app;

// $FF: synthetic class
class FragmentTabHost$1 {
}
