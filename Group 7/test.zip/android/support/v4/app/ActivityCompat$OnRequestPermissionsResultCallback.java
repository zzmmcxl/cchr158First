package android.support.v4.app;

import android.support.annotation.NonNull;

public interface ActivityCompat$OnRequestPermissionsResultCallback {
   void onRequestPermissionsResult(int var1, @NonNull String[] var2, @NonNull int[] var3);
}
