package android.support.v4.app;

public interface ActivityCompatApi23$RequestPermissionsRequestCodeValidator {
   void validateRequestPermissionsRequestCode(int var1);
}
