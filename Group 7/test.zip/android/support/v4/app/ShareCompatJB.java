package android.support.v4.app;

import android.text.Html;

class ShareCompatJB {
   public static String escapeHtml(CharSequence var0) {
      return Html.escapeHtml(var0);
   }
}
