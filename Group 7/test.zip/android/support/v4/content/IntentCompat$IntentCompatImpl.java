package android.support.v4.content;

import android.content.ComponentName;
import android.content.Intent;

interface IntentCompat$IntentCompatImpl {
   Intent makeMainActivity(ComponentName var1);

   Intent makeMainSelectorActivity(String var1, String var2);

   Intent makeRestartActivityTask(ComponentName var1);
}
