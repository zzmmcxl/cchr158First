package android.support.v4.content.res;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;

class ResourcesCompatIcsMr1 {
   public static Drawable getDrawableForDensity(Resources var0, int var1, int var2) throws NotFoundException {
      return var0.getDrawableForDensity(var1, var2);
   }
}
