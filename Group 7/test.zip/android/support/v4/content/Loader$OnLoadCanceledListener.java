package android.support.v4.content;

import android.support.v4.content.Loader;

public interface Loader$OnLoadCanceledListener<D> {
   void onLoadCanceled(Loader<D> var1);
}
