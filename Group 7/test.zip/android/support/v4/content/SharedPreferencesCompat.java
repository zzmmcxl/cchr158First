package android.support.v4.content;

public final class SharedPreferencesCompat {
}
