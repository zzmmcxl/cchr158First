package android.support.v4.content;

import android.support.v4.content.Loader;

public interface Loader$OnLoadCompleteListener<D> {
   void onLoadComplete(Loader<D> var1, D var2);
}
