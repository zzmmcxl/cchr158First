package android.support.v4.view.accessibility;

import android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$1;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;

class AccessibilityNodeProviderCompatJellyBean {
   public static Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge var0) {
      return new AccessibilityNodeProviderCompatJellyBean$1(var0);
   }
}
