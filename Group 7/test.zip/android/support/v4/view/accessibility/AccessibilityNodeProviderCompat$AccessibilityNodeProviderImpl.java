package android.support.v4.view.accessibility;

import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;

interface AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl {
   Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat var1);
}
