package android.support.v4.view.accessibility;

import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl;

class AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl implements AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl {
   public Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat var1) {
      return null;
   }
}
