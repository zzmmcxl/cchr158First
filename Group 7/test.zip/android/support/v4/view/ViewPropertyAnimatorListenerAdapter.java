package android.support.v4.view;

import android.support.v4.view.ViewPropertyAnimatorListener;
import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
   public void onAnimationCancel(View var1) {
   }

   public void onAnimationEnd(View var1) {
   }

   public void onAnimationStart(View var1) {
   }
}
