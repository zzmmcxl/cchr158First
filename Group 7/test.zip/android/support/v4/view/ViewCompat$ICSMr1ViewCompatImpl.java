package android.support.v4.view;

import android.support.v4.view.ViewCompat$ICSViewCompatImpl;
import android.support.v4.view.ViewCompatICSMr1;
import android.view.View;

class ViewCompat$ICSMr1ViewCompatImpl extends ViewCompat$ICSViewCompatImpl {
   public boolean hasOnClickListeners(View var1) {
      return ViewCompatICSMr1.hasOnClickListeners(var1);
   }
}
