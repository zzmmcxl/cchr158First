package android.support.v4.view;

import android.graphics.Paint;
import android.support.v4.view.ViewCompat$JBViewCompatImpl;
import android.support.v4.view.ViewCompatJellybeanMr1;
import android.view.View;

class ViewCompat$JbMr1ViewCompatImpl extends ViewCompat$JBViewCompatImpl {
   public int getLabelFor(View var1) {
      return ViewCompatJellybeanMr1.getLabelFor(var1);
   }

   public int getLayoutDirection(View var1) {
      return ViewCompatJellybeanMr1.getLayoutDirection(var1);
   }

   public int getPaddingEnd(View var1) {
      return ViewCompatJellybeanMr1.getPaddingEnd(var1);
   }

   public int getPaddingStart(View var1) {
      return ViewCompatJellybeanMr1.getPaddingStart(var1);
   }

   public int getWindowSystemUiVisibility(View var1) {
      return ViewCompatJellybeanMr1.getWindowSystemUiVisibility(var1);
   }

   public boolean isPaddingRelative(View var1) {
      return ViewCompatJellybeanMr1.isPaddingRelative(var1);
   }

   public void setLabelFor(View var1, int var2) {
      ViewCompatJellybeanMr1.setLabelFor(var1, var2);
   }

   public void setLayerPaint(View var1, Paint var2) {
      ViewCompatJellybeanMr1.setLayerPaint(var1, var2);
   }

   public void setLayoutDirection(View var1, int var2) {
      ViewCompatJellybeanMr1.setLayoutDirection(var1, var2);
   }

   public void setPaddingRelative(View var1, int var2, int var3, int var4, int var5) {
      ViewCompatJellybeanMr1.setPaddingRelative(var1, var2, var3, var4, var5);
   }
}
