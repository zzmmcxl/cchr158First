package android.support.v4.view;

interface ScaleGestureDetectorCompat$ScaleGestureDetectorImpl {
   boolean isQuickScaleEnabled(Object var1);

   void setQuickScaleEnabled(Object var1, boolean var2);
}
