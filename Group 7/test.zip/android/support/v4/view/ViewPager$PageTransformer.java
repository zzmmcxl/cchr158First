package android.support.v4.view;

import android.view.View;

public interface ViewPager$PageTransformer {
   void transformPage(View var1, float var2);
}
