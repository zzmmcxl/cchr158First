package android.support.v4.view;

import android.support.v4.view.PagerAdapter;

interface ViewPager$OnAdapterChangeListener {
   void onAdapterChanged(PagerAdapter var1, PagerAdapter var2);
}
