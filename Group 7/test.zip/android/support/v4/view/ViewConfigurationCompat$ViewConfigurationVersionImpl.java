package android.support.v4.view;

import android.view.ViewConfiguration;

interface ViewConfigurationCompat$ViewConfigurationVersionImpl {
   int getScaledPagingTouchSlop(ViewConfiguration var1);

   boolean hasPermanentMenuKey(ViewConfiguration var1);
}
