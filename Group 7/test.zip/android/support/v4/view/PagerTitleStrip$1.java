package android.support.v4.view;

// $FF: synthetic class
class PagerTitleStrip$1 {
}
