package android.support.v4.view;

import android.view.View;

class ViewCompatGingerbread {
   public static int getOverScrollMode(View var0) {
      return var0.getOverScrollMode();
   }

   public static void setOverScrollMode(View var0, int var1) {
      var0.setOverScrollMode(var1);
   }
}
