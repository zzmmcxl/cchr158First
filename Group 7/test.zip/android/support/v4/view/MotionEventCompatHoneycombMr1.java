package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatHoneycombMr1 {
   static float getAxisValue(MotionEvent var0, int var1) {
      return var0.getAxisValue(var1);
   }

   static float getAxisValue(MotionEvent var0, int var1, int var2) {
      return var0.getAxisValue(var1, var2);
   }
}
