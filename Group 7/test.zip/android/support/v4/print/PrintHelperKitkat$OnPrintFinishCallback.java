package android.support.v4.print;

public interface PrintHelperKitkat$OnPrintFinishCallback {
   void onFinish();
}
