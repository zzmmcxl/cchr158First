package android.support.v4.os;

public interface CancellationSignal$OnCancelListener {
   void onCancel();
}
