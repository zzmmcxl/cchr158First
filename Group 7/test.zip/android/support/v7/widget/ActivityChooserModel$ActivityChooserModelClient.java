package android.support.v7.widget;

import android.support.v7.widget.ActivityChooserModel;

public interface ActivityChooserModel$ActivityChooserModelClient {
   void setActivityChooserModel(ActivityChooserModel var1);
}
