package android.support.v7.widget;

import android.graphics.Rect;

public interface FitWindowsViewGroup$OnFitSystemWindowsListener {
   void onFitSystemWindows(Rect var1);
}
