package android.support.v7.widget.helper;

import android.view.View;

public interface ItemTouchHelper$ViewDropHandler {
   void prepareForDrop(View var1, View var2, int var3, int var4);
}
