package android.support.v7.widget;

import android.support.v7.widget.RecyclerView$ViewHolder;

interface RecyclerView$ItemAnimator$ItemAnimatorListener {
   void onAnimationFinished(RecyclerView$ViewHolder var1);
}
