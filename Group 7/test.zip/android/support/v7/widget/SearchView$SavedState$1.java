package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v7.widget.SearchView$SavedState;

final class SearchView$SavedState$1 implements Creator<SearchView$SavedState> {
   public SearchView$SavedState createFromParcel(Parcel var1) {
      return new SearchView$SavedState(var1);
   }

   public SearchView$SavedState[] newArray(int var1) {
      return new SearchView$SavedState[var1];
   }
}
