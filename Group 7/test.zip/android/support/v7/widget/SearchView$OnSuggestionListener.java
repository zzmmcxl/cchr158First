package android.support.v7.widget;

public interface SearchView$OnSuggestionListener {
   boolean onSuggestionClick(int var1);

   boolean onSuggestionSelect(int var1);
}
