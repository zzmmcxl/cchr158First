package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v7.widget.StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;

final class StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem$1 implements Creator<StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem> {
   public StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem createFromParcel(Parcel var1) {
      return new StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem(var1);
   }

   public StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem[] newArray(int var1) {
      return new StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem[var1];
   }
}
