package android.support.v7.widget;

import android.content.Intent;
import android.support.v7.widget.ActivityChooserModel$ActivityResolveInfo;
import android.support.v7.widget.ActivityChooserModel$HistoricalRecord;
import java.util.List;

public interface ActivityChooserModel$ActivitySorter {
   void sort(Intent var1, List<ActivityChooserModel$ActivityResolveInfo> var2, List<ActivityChooserModel$HistoricalRecord> var3);
}
