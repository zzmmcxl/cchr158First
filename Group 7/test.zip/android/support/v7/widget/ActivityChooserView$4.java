package android.support.v7.widget;

import android.database.DataSetObserver;
import android.support.v7.widget.ActivityChooserView;

class ActivityChooserView$4 extends DataSetObserver {
   ActivityChooserView$4(ActivityChooserView var1) {
      this.this$0 = var1;
   }

   public void onChanged() {
      super.onChanged();
      ActivityChooserView.access$400(this.this$0);
   }
}
