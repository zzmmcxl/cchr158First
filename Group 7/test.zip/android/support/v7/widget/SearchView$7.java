package android.support.v7.widget;

import android.support.v7.widget.SearchView;
import android.view.View;
import android.view.View.OnClickListener;

class SearchView$7 implements OnClickListener {
   SearchView$7(SearchView var1) {
      this.this$0 = var1;
   }

   public void onClick(View var1) {
      if(var1 == SearchView.access$400(this.this$0)) {
         SearchView.access$500(this.this$0);
      } else {
         if(var1 == SearchView.access$600(this.this$0)) {
            SearchView.access$700(this.this$0);
            return;
         }

         if(var1 == SearchView.access$800(this.this$0)) {
            SearchView.access$900(this.this$0);
            return;
         }

         if(var1 == SearchView.access$1000(this.this$0)) {
            SearchView.access$1100(this.this$0);
            return;
         }

         if(var1 == SearchView.access$1200(this.this$0)) {
            SearchView.access$1300(this.this$0);
            return;
         }
      }

   }
}
