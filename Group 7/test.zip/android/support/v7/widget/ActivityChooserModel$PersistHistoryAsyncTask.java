package android.support.v7.widget;

import android.os.AsyncTask;
import android.support.v7.widget.ActivityChooserModel;

final class ActivityChooserModel$PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void> {
   private ActivityChooserModel$PersistHistoryAsyncTask(ActivityChooserModel var1) {
      this.this$0 = var1;
   }

   public Void doInBackground(Object... param1) {
      // $FF: Couldn't be decompiled
   }
}
