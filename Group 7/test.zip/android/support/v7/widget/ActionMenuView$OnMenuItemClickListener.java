package android.support.v7.widget;

import android.view.MenuItem;

public interface ActionMenuView$OnMenuItemClickListener {
   boolean onMenuItemClick(MenuItem var1);
}
