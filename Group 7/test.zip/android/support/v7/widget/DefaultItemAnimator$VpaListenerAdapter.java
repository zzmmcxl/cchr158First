package android.support.v7.widget;

import android.support.v4.view.ViewPropertyAnimatorListener;
import android.view.View;

class DefaultItemAnimator$VpaListenerAdapter implements ViewPropertyAnimatorListener {
   private DefaultItemAnimator$VpaListenerAdapter() {
   }

   public void onAnimationCancel(View var1) {
   }

   public void onAnimationEnd(View var1) {
   }

   public void onAnimationStart(View var1) {
   }
}
