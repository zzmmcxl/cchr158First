package android.support.v7.widget;

public interface ContentFrameLayout$OnAttachListener {
   void onAttachedFromWindow();

   void onDetachedFromWindow();
}
