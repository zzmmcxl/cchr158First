package android.support.v7.widget;

import android.view.MenuItem;

public interface Toolbar$OnMenuItemClickListener {
   boolean onMenuItemClick(MenuItem var1);
}
