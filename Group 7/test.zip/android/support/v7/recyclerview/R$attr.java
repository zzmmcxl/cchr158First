package android.support.v7.recyclerview;

public final class R$attr {
   public static final int layoutManager = 2130772178;
   public static final int reverseLayout = 2130772180;
   public static final int spanCount = 2130772179;
   public static final int stackFromEnd = 2130772181;
}
