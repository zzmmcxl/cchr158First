package android.support.v7.recyclerview;

public final class R$styleable {
   public static final int[] RecyclerView = new int[]{16842948, 2130772178, 2130772179, 2130772180, 2130772181};
   public static final int RecyclerView_android_orientation = 0;
   public static final int RecyclerView_layoutManager = 1;
   public static final int RecyclerView_reverseLayout = 3;
   public static final int RecyclerView_spanCount = 2;
   public static final int RecyclerView_stackFromEnd = 4;
}
