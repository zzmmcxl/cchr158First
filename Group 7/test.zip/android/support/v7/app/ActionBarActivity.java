package android.support.v7.app;

import android.support.v7.app.AppCompatActivity;

@Deprecated
public class ActionBarActivity extends AppCompatActivity {
}
