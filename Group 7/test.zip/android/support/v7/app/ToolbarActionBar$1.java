package android.support.v7.app;

import android.support.v7.app.ToolbarActionBar;

class ToolbarActionBar$1 implements Runnable {
   ToolbarActionBar$1(ToolbarActionBar var1) {
      this.this$0 = var1;
   }

   public void run() {
      this.this$0.populateOptionsMenu();
   }
}
