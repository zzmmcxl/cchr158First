package android.support.v7.app;

interface ActionBarDrawerToggle$DrawerToggle {
   float getPosition();

   void setPosition(float var1);
}
