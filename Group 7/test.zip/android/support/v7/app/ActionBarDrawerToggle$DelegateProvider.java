package android.support.v7.app;

import android.support.annotation.Nullable;
import android.support.v7.app.ActionBarDrawerToggle$Delegate;

public interface ActionBarDrawerToggle$DelegateProvider {
   @Nullable
   ActionBarDrawerToggle$Delegate getDrawerToggleDelegate();
}
