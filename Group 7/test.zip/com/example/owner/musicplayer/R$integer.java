package com.example.owner.musicplayer;

public final class R$integer {
   public static final int abc_config_activityDefaultDur = 2131361794;
   public static final int abc_config_activityShortDur = 2131361795;
   public static final int abc_max_action_buttons = 2131361792;
   public static final int bottom_sheet_slide_duration = 2131361796;
   public static final int cancel_button_image_alpha = 2131361797;
   public static final int design_snackbar_text_max_lines = 2131361793;
   public static final int status_bar_notification_info_maxnum = 2131361798;
}
