package com.example.owner.musicplayer;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.example.owner.musicplayer.jsr438w4171f7096744c329292z606416yy178033s399lhd2226fgs37mfu97em56zgt3$bkv3523rqvc154051z146pqz54l34q38ujcx6211au2959i6368gdes982958eze95952;
import com.example.owner.musicplayer.szr58w75mpfxi23wc7m10p75ym50j39o8912wlcfdba3967tng81l49314045510925;

class szr58w75mpfxi23wc7m10p75ym50j39o8912wlcfdba3967tng81l49314045510925$2 implements ServiceConnection {
   szr58w75mpfxi23wc7m10p75ym50j39o8912wlcfdba3967tng81l49314045510925$2(szr58w75mpfxi23wc7m10p75ym50j39o8912wlcfdba3967tng81l49314045510925 var1) {
      this.this$0 = var1;
   }

   public void onServiceConnected(ComponentName var1, IBinder var2) {
      jsr438w4171f7096744c329292z606416yy178033s399lhd2226fgs37mfu97em56zgt3$bkv3523rqvc154051z146pqz54l34q38ujcx6211au2959i6368gdes982958eze95952 var3 = (jsr438w4171f7096744c329292z606416yy178033s399lhd2226fgs37mfu97em56zgt3$bkv3523rqvc154051z146pqz54l34q38ujcx6211au2959i6368gdes982958eze95952)var2;
      szr58w75mpfxi23wc7m10p75ym50j39o8912wlcfdba3967tng81l49314045510925.access$202(this.this$0, var3.tux7178q246614s11y49y54876184m92z72m29rv018udvsf4134942i53441833oybd66l27());
      this.this$0.ols59225260a21392a5215371655p56ss29o703849808432fg74c21kp224164ma888641t72m8068 = true;
   }

   public void onServiceDisconnected(ComponentName var1) {
      this.this$0.ols59225260a21392a5215371655p56ss29o703849808432fg74c21kp224164ma888641t72m8068 = false;
   }
}
