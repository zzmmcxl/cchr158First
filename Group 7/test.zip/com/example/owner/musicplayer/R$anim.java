package com.example.owner.musicplayer;

public final class R$anim {
   public static final int abc_fade_in = 2131034112;
   public static final int abc_fade_out = 2131034113;
   public static final int abc_grow_fade_in_from_bottom = 2131034114;
   public static final int abc_popup_enter = 2131034115;
   public static final int abc_popup_exit = 2131034116;
   public static final int abc_shrink_fade_out_from_bottom = 2131034117;
   public static final int abc_slide_in_bottom = 2131034118;
   public static final int abc_slide_in_top = 2131034119;
   public static final int abc_slide_out_bottom = 2131034120;
   public static final int abc_slide_out_top = 2131034121;
   public static final int design_bottom_sheet_slide_in = 2131034122;
   public static final int design_bottom_sheet_slide_out = 2131034123;
   public static final int design_fab_in = 2131034124;
   public static final int design_fab_out = 2131034125;
   public static final int design_snackbar_in = 2131034126;
   public static final int design_snackbar_out = 2131034127;
}
