package com.woop.tryreverseengineerthis;

import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Base64;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/* renamed from: com.woop.tryreverseengineerthis.I */
public class C0596I {
    private static HashMap<String, String> l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1;
    private static HashMap<String, String> l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l;
    String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l;

    public C0596I() {
        this.l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = "-80120591";
    }

    public static void m21xde12b279(Context o1) throws NoSuchPaddingException, NoSuchAlgorithmException {
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = "991922159";
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1 = new HashMap();
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = new HashMap();
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = Build.FINGERPRINT;
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1 = Build.MODEL;
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = Build.MANUFACTURER;
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1 = Build.PRODUCT;
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = Build.HARDWARE;
        String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l = ((TelephonyManager) o1.getSystemService("phone")).getNetworkOperator();
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("ONE1111111111", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("TWO2222222222", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("THREE33333333", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("FOUR444444444", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("FIVE555555555", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.put("ELVEN11111111", l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l);
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("OnceUponATime", "Z2VuZXJpYw==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("LivedABunnyCalled", "dW5rbm93bg==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("Judy.SheWasGoingTo", "Z29vZ2xlX3Nkaw==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("OoposN10earlyforGot", "ZW11bGF0b3I=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("beTheBestCopIn", "YW5kcm9pZF9zZGtfODY=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("Zo0o0o0o0Topia", "Z2VueW1vdGlvbg==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("SheDidNotRealise", "c2Rr");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("however,ThatShe", "c2RrXzg2");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("wasJustGoingtobe", "dmJveA==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("amereparkingWarden", "Z29sZGZpc2g=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("sadfacebunny", "YW5kcm9pZA==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("d102jd012jasd", "aHR0cDovL3d3dy50aGlzaXNhZmFrZXVybGZvcmNvbXBzY2k3MDIuY29tLw==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("uas0j1d12dasDas", "UE9TVA==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("aspdk2DasdmaSDa==", "Q29udGVudC1UeXBl");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("as=sdnasd2d22d2", "YXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVk");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("ask20asdj20jd9", "Y2hhcnNldA==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("asdSDs22d@d222==", "dXRmLTg=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("20k20dk20ASD2d==", "Q29udGVudC1MZW5ndGg=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("d2jasaSD2dasd==", "LTM2Ljg2");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("sdD22d3daSd2==", "LTM2Ljg0");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("asd202d0asD2==", "MTc0Ljc2");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("asdk22d2djiasd0", "MTc1Ljc4");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("a2d0jdASd22ASd22j0", "MjU2");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("ajd202ASsd20L022", "MTc=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("ajd202ASsd20L025", "MTc=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("ajd202ASsd20L026", "MTY=");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("apsojdojaspdjaspo", "Tm8gY2xhc3NlcyB0b2RheSBmb3Ig");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("dj20jd02j0d2j0d2jd0", "Q2Fubm90IGRldGVjdCBsb2NhdGlvbg==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("apsodjpo2jdopj1oassd", "WW91IGFyZSBub3QgaW4gdGhlIHJpZ2h0IGxvY2F0aW9u");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("dasodj02jd02jd02d2", "Q2xhc3MgaXMgbm90IG5vdw==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("aspodjaopdjasodjasso", "Q2hlY2tlZCBpbg==");
        l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.put("sojodsojdsjodsojsdjo11", "T25seSA3MDIgaXMgc3VwcG9ydGVk");
    }

    private static boolean L1L1L1L1L1L1L1(String o1o) {
        if (o1o.length() == 16) {
            return true;
        }
        return false;
    }

    private static boolean L1L1L1L1L1L1L1(int o1o) {
        if ((((double) o1o) / 2.0d) % 2.0d != 1.0d) {
            return true;
        }
        return false;
    }

    public static String m22xe4439d13(String o1o1o) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        return (String) l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1.get(new String(Base64.decode(o1o1o, 0)));
    }

    public static String m23xa430057e(String l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        return new String(Base64.decode((String) l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l.get(l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1l1), 0));
    }
}
