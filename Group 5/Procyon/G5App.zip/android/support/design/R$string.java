package android.support.design;

public static final class string
{
    public static final int abc_action_bar_home_description = 2131165184;
    public static final int abc_action_bar_home_description_format = 2131165185;
    public static final int abc_action_bar_home_subtitle_description_format = 2131165186;
    public static final int abc_action_bar_up_description = 2131165187;
    public static final int abc_action_menu_overflow_description = 2131165188;
    public static final int abc_action_mode_done = 2131165189;
    public static final int abc_activity_chooser_view_see_all = 2131165190;
    public static final int abc_activitychooserview_choose_application = 2131165191;
    public static final int abc_capital_off = 2131165192;
    public static final int abc_capital_on = 2131165193;
    public static final int abc_search_hint = 2131165194;
    public static final int abc_searchview_description_clear = 2131165195;
    public static final int abc_searchview_description_query = 2131165196;
    public static final int abc_searchview_description_search = 2131165197;
    public static final int abc_searchview_description_submit = 2131165198;
    public static final int abc_searchview_description_voice = 2131165199;
    public static final int abc_shareactionprovider_share_with = 2131165200;
    public static final int abc_shareactionprovider_share_with_application = 2131165201;
    public static final int abc_toolbar_collapse_description = 2131165202;
    public static final int appbar_scrolling_view_behavior = 2131165250;
    public static final int bottom_sheet_behavior = 2131165253;
    public static final int character_counter_pattern = 2131165257;
    public static final int status_bar_notification_info_overflow = 2131165245;
}
