package android.support.design.widget;

import android.support.annotation.*;

public abstract static class DragCallback
{
    public abstract boolean canDrag(@NonNull final AppBarLayout p0);
}
