package android.support.design.widget;

import android.os.*;

static final class TextInputLayout$SavedState$1 implements Parcelable$Creator<SavedState> {
    public SavedState createFromParcel(final Parcel parcel) {
        return new SavedState(parcel);
    }
    
    public SavedState[] newArray(final int n) {
        return new SavedState[n];
    }
}