package android.support.design.widget;

interface Creator
{
    ValueAnimatorCompat createAnimator();
}
