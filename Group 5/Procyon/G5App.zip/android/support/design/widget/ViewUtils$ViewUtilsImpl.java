package android.support.design.widget;

import android.view.*;

private interface ViewUtilsImpl
{
    void setBoundsViewOutlineProvider(final View p0);
}
