package android.support.design.widget;

class Snackbar$5$1 implements Runnable {
    @Override
    public void run() {
        Snackbar.access$300(OnAttachStateChangeListener.this.this$0, 3);
    }
}