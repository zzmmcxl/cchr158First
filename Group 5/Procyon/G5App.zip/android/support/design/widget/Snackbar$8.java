package android.support.design.widget;

import android.view.animation.*;

class Snackbar$8 implements Animation$AnimationListener {
    public void onAnimationEnd(final Animation animation) {
        Snackbar.access$700(Snackbar.this);
    }
    
    public void onAnimationRepeat(final Animation animation) {
    }
    
    public void onAnimationStart(final Animation animation) {
    }
}