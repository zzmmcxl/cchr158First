package android.support.design.widget;

import android.animation.*;

class ValueAnimatorCompatImplHoneycombMr1$1 implements ValueAnimator$AnimatorUpdateListener {
    final /* synthetic */ AnimatorUpdateListenerProxy val$updateListener;
    
    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
        this.val$updateListener.onAnimationUpdate();
    }
}