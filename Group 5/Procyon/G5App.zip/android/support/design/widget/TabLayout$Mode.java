package android.support.design.widget;

import java.lang.annotation.*;

@Retention(RetentionPolicy.SOURCE)
public @interface Mode {
}
