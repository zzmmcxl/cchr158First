package android.support.design.widget;

import android.view.animation.*;

static class AnimationListenerAdapter implements Animation$AnimationListener
{
    public void onAnimationEnd(final Animation animation) {
    }
    
    public void onAnimationRepeat(final Animation animation) {
    }
    
    public void onAnimationStart(final Animation animation) {
    }
}
