package android.support.design.widget;

interface InternalVisibilityChangedListener
{
    void onHidden();
    
    void onShown();
}
