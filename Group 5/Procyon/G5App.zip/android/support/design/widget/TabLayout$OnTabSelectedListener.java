package android.support.design.widget;

public interface OnTabSelectedListener
{
    void onTabReselected(final Tab p0);
    
    void onTabSelected(final Tab p0);
    
    void onTabUnselected(final Tab p0);
}
