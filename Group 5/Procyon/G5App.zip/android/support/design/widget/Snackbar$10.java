package android.support.design.widget;

import android.view.animation.*;

class Snackbar$10 implements Animation$AnimationListener {
    final /* synthetic */ int val$event;
    
    public void onAnimationEnd(final Animation animation) {
        Snackbar.access$300(Snackbar.this, this.val$event);
    }
    
    public void onAnimationRepeat(final Animation animation) {
    }
    
    public void onAnimationStart(final Animation animation) {
    }
}