package android.support.design.widget;

import android.view.*;

interface OnLayoutChangeListener
{
    void onLayoutChange(final View p0, final int p1, final int p2, final int p3, final int p4);
}
