package android.support.design.widget;

interface Callback
{
    void dismiss(final int p0);
    
    void show();
}
