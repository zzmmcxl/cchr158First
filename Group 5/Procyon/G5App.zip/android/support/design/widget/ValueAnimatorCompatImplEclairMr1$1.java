package android.support.design.widget;

class ValueAnimatorCompatImplEclairMr1$1 implements Runnable {
    @Override
    public void run() {
        ValueAnimatorCompatImplEclairMr1.access$000(ValueAnimatorCompatImplEclairMr1.this);
    }
}