package android.support.design.widget;

interface AnimatorUpdateListenerProxy
{
    void onAnimationUpdate();
}
