package android.support.design.widget;

import android.view.*;

class Snackbar$2 implements View$OnClickListener {
    final /* synthetic */ View$OnClickListener val$listener;
    
    public void onClick(final View view) {
        this.val$listener.onClick(view);
        Snackbar.access$000(Snackbar.this, 1);
    }
}