package android.support.design.widget;

import android.view.*;

class FloatingActionButtonImpl$1 implements ViewTreeObserver$OnPreDrawListener {
    public boolean onPreDraw() {
        FloatingActionButtonImpl.this.onPreDraw();
        return true;
    }
}