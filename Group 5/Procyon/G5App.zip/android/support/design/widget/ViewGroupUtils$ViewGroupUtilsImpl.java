package android.support.design.widget;

import android.view.*;
import android.graphics.*;

private interface ViewGroupUtilsImpl
{
    void offsetDescendantRect(final ViewGroup p0, final View p1, final Rect p2);
}
