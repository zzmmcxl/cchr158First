package android.support.design.widget;

import android.database.*;

private class PagerAdapterObserver extends DataSetObserver
{
    public void onChanged() {
        TabLayout.access$2800(TabLayout.this);
    }
    
    public void onInvalidated() {
        TabLayout.access$2800(TabLayout.this);
    }
}
