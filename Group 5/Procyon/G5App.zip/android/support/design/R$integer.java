package android.support.design;

public static final class integer
{
    public static final int abc_config_activityDefaultDur = 2131427330;
    public static final int abc_config_activityShortDur = 2131427331;
    public static final int abc_max_action_buttons = 2131427328;
    public static final int bottom_sheet_slide_duration = 2131427332;
    public static final int cancel_button_image_alpha = 2131427333;
    public static final int design_snackbar_text_max_lines = 2131427329;
    public static final int status_bar_notification_info_maxnum = 2131427335;
}
