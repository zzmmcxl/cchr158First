package android.support.design.internal;

private interface NavigationMenuItem
{
}
