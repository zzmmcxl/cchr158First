package android.support.v4.animation;

import android.animation.*;

class HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1 implements ValueAnimator$AnimatorUpdateListener {
    final /* synthetic */ AnimatorUpdateListenerCompat val$animatorUpdateListener;
    
    public void onAnimationUpdate(final ValueAnimator valueAnimator) {
        this.val$animatorUpdateListener.onAnimationUpdate(HoneycombValueAnimatorCompat.this);
    }
}