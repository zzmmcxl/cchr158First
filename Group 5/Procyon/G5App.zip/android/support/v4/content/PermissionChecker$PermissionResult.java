package android.support.v4.content;

import java.lang.annotation.*;

@Retention(RetentionPolicy.SOURCE)
public @interface PermissionResult {
}
