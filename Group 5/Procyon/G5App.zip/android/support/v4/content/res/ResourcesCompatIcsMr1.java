package android.support.v4.content.res;

import android.graphics.drawable.*;
import android.content.res.*;

class ResourcesCompatIcsMr1
{
    public static Drawable getDrawableForDensity(final Resources resources, final int n, final int n2) throws Resources$NotFoundException {
        return resources.getDrawableForDensity(n, n2);
    }
}
