package android.support.v4.content;

import android.content.*;
import android.support.annotation.*;

private interface Helper
{
    void apply(@NonNull final SharedPreferences$Editor p0);
}
