package android.support.v4.content;

public enum Status
{
    FINISHED, 
    PENDING, 
    RUNNING;
}
