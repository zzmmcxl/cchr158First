package android.support.v4.media;

interface ConnectionCallbackInternal
{
    void onConnected();
    
    void onConnectionFailed();
    
    void onConnectionSuspended();
}
