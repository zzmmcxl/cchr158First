package android.support.v4.media;

class MediaBrowserCompat$MediaBrowserImplApi21$2 implements Runnable {
    final /* synthetic */ ItemCallback val$cb;
    
    @Override
    public void run() {
        this.val$cb.onItemLoaded(null);
    }
}