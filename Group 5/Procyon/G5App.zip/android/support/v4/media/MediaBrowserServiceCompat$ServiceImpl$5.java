package android.support.v4.media;

import android.support.v4.os.*;

class MediaBrowserServiceCompat$ServiceImpl$5 implements Runnable {
    final /* synthetic */ String val$mediaId;
    final /* synthetic */ ResultReceiver val$receiver;
    
    @Override
    public void run() {
        MediaBrowserServiceCompat.access$900(ServiceImpl.this.this$0, this.val$mediaId, this.val$receiver);
    }
}