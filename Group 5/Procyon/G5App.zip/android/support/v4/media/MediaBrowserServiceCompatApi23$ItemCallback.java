package android.support.v4.media;

import android.os.*;

public interface ItemCallback
{
    void onItemLoaded(final int p0, final Bundle p1, final Parcel p2);
}
