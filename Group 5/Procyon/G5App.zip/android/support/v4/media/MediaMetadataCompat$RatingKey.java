package android.support.v4.media;

import java.lang.annotation.*;

@Retention(RetentionPolicy.SOURCE)
public @interface RatingKey {
}
