package android.support.v4.media;

import android.view.*;

class TransportMediatorJellybeanMR2$1 implements ViewTreeObserver$OnWindowAttachListener {
    public void onWindowAttached() {
        TransportMediatorJellybeanMR2.this.windowAttached();
    }
    
    public void onWindowDetached() {
        TransportMediatorJellybeanMR2.this.windowDetached();
    }
}