package android.support.v4.media;

public abstract static class Callback
{
    public abstract void onVolumeChanged(final VolumeProviderCompat p0);
}
