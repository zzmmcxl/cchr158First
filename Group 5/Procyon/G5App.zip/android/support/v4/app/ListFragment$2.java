package android.support.v4.app;

import android.view.*;
import android.widget.*;

class ListFragment$2 implements AdapterView$OnItemClickListener {
    public void onItemClick(final AdapterView<?> adapterView, final View view, final int n, final long n2) {
        ListFragment.this.onListItemClick((ListView)adapterView, view, n, n2);
    }
}