package android.support.v4.app;

import android.view.*;

public interface ViewRetriever
{
    View getView();
}
