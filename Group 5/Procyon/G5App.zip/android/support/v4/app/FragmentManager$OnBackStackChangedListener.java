package android.support.v4.app;

public interface OnBackStackChangedListener
{
    void onBackStackChanged();
}
