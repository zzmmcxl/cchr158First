package android.support.v4.app;

import android.support.v4.view.*;
import android.graphics.*;

class FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$1 implements Runnable {
    @Override
    public void run() {
        ViewCompat.setLayerType(AnimateOnHWLayerIfNeededListener.access$000(AnimateOnHWLayerIfNeededListener.this), 2, null);
    }
}