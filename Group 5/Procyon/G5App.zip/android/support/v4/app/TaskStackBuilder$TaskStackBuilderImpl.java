package android.support.v4.app;

import android.content.*;
import android.os.*;
import android.app.*;

interface TaskStackBuilderImpl
{
    PendingIntent getPendingIntent(final Context p0, final Intent[] p1, final int p2, final int p3, final Bundle p4);
}
