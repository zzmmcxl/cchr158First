package android.support.v4.app;

import android.view.*;

public static class EpicenterView
{
    public View epicenter;
}
