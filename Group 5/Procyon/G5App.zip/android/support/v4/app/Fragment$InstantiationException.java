package android.support.v4.app;

public static class InstantiationException extends RuntimeException
{
    public InstantiationException(final String s, final Exception ex) {
        super(s, ex);
    }
}
