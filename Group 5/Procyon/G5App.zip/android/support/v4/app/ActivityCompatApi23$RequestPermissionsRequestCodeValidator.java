package android.support.v4.app;

public interface RequestPermissionsRequestCodeValidator
{
    void validateRequestPermissionsRequestCode(final int p0);
}
