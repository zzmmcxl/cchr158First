package android.support.v4.app;

import android.graphics.*;
import android.transition.*;

static final class FragmentTransitionCompat21$1 extends Transition$EpicenterCallback {
    final /* synthetic */ Rect val$epicenter;
    
    public Rect onGetEpicenter(final Transition transition) {
        return this.val$epicenter;
    }
}