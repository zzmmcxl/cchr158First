package android.support.v4.app;

import android.content.*;

public interface SupportParentable
{
    Intent getSupportParentActivityIntent();
}
