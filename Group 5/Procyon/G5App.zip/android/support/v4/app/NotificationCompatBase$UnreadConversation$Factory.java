package android.support.v4.app;

import android.app.*;

public interface Factory
{
    UnreadConversation build(final String[] p0, final RemoteInputCompatBase.RemoteInput p1, final PendingIntent p2, final PendingIntent p3, final String[] p4, final long p5);
}
