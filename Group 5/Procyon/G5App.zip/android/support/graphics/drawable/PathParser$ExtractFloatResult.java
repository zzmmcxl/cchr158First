package android.support.graphics.drawable;

private static class ExtractFloatResult
{
    int mEndPosition;
    boolean mEndWithNegOrDot;
}
