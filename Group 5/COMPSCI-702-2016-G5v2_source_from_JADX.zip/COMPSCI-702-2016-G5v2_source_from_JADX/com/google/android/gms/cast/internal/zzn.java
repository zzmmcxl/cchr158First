package com.google.android.gms.cast.internal;

import java.io.IOException;

public interface zzn {
    void zza(String str, String str2, long j, String str3) throws IOException;

    long zznQ();
}
