package com.google.android.gms.wearable;

public interface zzc {

    public interface zza {
        void zza(zzd com_google_android_gms_wearable_zzd);
    }
}
