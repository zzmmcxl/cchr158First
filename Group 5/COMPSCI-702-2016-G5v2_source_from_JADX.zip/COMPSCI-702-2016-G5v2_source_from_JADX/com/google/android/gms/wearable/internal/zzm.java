package com.google.android.gms.wearable.internal;

final class zzm {
    final int zzbsa;
    final int zzbsb;

    zzm(int i, int i2) {
        this.zzbsa = i;
        this.zzbsb = i2;
    }
}
