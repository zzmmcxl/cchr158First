package com.google.android.gms.wearable;

public interface zza {

    public interface zza {
        void zza(zzb com_google_android_gms_wearable_zzb);
    }
}
