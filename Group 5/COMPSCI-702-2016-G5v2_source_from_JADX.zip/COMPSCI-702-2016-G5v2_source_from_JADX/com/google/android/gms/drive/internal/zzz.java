package com.google.android.gms.drive.internal;

import android.content.Context;
import com.google.android.gms.common.internal.zzo;

public final class zzz {
    private static final zzo zzart;

    static {
        zzart = new zzo("GmsDrive");
    }

    public static void zzA(String str, String str2) {
        zzart.zzA(str, str2);
    }

    public static void zza(Context context, String str, String str2, Throwable th) {
        zzart.zza(context, str, str2, th);
    }

    public static void zza(String str, Throwable th, String str2) {
        zzart.zzc(str, str2, th);
    }

    public static void zze(Context context, String str, String str2) {
        zza(context, str, str2, new Throwable());
    }

    public static void zzy(String str, String str2) {
        zzart.zzy(str, str2);
    }

    public static void zzz(String str, String str2) {
        zzart.zzz(str, str2);
    }
}
