package com.google.android.gms.drive.metadata;

public abstract class zzd<T extends Comparable<T>> extends zza<T> {
    protected zzd(String str, int i) {
        super(str, i);
    }
}
