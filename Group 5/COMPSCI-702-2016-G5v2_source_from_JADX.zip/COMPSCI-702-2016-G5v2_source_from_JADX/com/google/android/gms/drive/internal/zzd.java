package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.ChangeSequenceNumber;
import com.google.android.gms.drive.internal.zzan.zza;
import com.google.android.gms.drive.realtime.internal.zzm;

public class zzd extends zza {
    public void onError(Status status) throws RemoteException {
    }

    public void onSuccess() throws RemoteException {
    }

    public void zza(ChangeSequenceNumber changeSequenceNumber) throws RemoteException {
    }

    public void zza(GetPermissionsResponse getPermissionsResponse) throws RemoteException {
    }

    public void zza(OnChangesResponse onChangesResponse) throws RemoteException {
    }

    public void zza(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    public void zza(OnDeviceUsagePreferenceResponse onDeviceUsagePreferenceResponse) throws RemoteException {
    }

    public void zza(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    public void zza(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    public void zza(OnFetchThumbnailResponse onFetchThumbnailResponse) throws RemoteException {
    }

    public void zza(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    public void zza(OnListParentsResponse onListParentsResponse) throws RemoteException {
    }

    public void zza(OnLoadRealtimeResponse onLoadRealtimeResponse, zzm com_google_android_gms_drive_realtime_internal_zzm) throws RemoteException {
    }

    public void zza(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    public void zza(OnPinnedDownloadPreferencesResponse onPinnedDownloadPreferencesResponse) throws RemoteException {
    }

    public void zza(OnResourceIdSetResponse onResourceIdSetResponse) throws RemoteException {
    }

    public void zza(OnStartStreamSession onStartStreamSession) throws RemoteException {
    }

    public void zza(OnSyncMoreResponse onSyncMoreResponse) throws RemoteException {
    }

    public void zza(StringListResponse stringListResponse) throws RemoteException {
    }

    public void zzaf(boolean z) throws RemoteException {
    }
}
