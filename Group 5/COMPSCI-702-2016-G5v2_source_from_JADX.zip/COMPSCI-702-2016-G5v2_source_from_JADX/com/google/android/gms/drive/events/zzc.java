package com.google.android.gms.drive.events;

public interface zzc extends zzf {
    void zza(ChangesAvailableEvent changesAvailableEvent);
}
