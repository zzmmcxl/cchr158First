package com.google.android.gms.drive.events;

public interface zzm extends zzf {
    void zza(zzk com_google_android_gms_drive_events_zzk);

    void zzcJ(int i);
}
