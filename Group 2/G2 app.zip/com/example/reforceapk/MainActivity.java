package com.example.reforceapk;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
   protected void onCreate(Bundle var1) {
      super.onCreate(var1);
      this.setContentView(2130968601);
   }
}
