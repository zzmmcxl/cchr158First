package android.support.v4.os;

import android.os.Parcelable.Creator;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.os.ParcelableCompatCreatorHoneycombMR2;

class ParcelableCompatCreatorHoneycombMR2Stub {
   static Creator instantiate(ParcelableCompatCreatorCallbacks var0) {
      return new ParcelableCompatCreatorHoneycombMR2(var0);
   }
}
