package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatGingerbread {
   public static int getSource(MotionEvent var0) {
      return var0.getSource();
   }
}
