package android.support.v4.view;

import android.support.v4.view.MenuItemCompat;
import android.view.MenuItem;

public class MenuCompat {
   @Deprecated
   public static void setShowAsAction(MenuItem var0, int var1) {
      MenuItemCompat.setShowAsAction(var0, var1);
   }
}
