package android.support.v4.view;

import android.view.ViewGroup;

class ViewGroupCompatJellybeanMR2 {
   public static int getLayoutMode(ViewGroup var0) {
      return var0.getLayoutMode();
   }

   public static void setLayoutMode(ViewGroup var0, int var1) {
      var0.setLayoutMode(var1);
   }
}
