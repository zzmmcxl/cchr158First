package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;

class AccessibilityServiceInfoCompatJellyBeanMr2 {
   public static int getCapabilities(AccessibilityServiceInfo var0) {
      return var0.getCapabilities();
   }
}
