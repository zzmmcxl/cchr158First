package android.support.v4.media;

import android.support.v4.media.TransportController;

public class TransportStateListener {
   public void onPlayingChanged(TransportController var1) {
   }

   public void onTransportControlsChanged(TransportController var1) {
   }
}
