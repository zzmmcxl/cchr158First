package android.support.v4.text;

public interface TextDirectionHeuristicCompat {
   boolean isRtl(CharSequence var1, int var2, int var3);

   boolean isRtl(char[] var1, int var2, int var3);
}
