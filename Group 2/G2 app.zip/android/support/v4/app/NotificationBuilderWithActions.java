package android.support.v4.app;

import android.support.v4.app.NotificationCompatBase;

interface NotificationBuilderWithActions {
   void addAction(NotificationCompatBase.Action var1);
}
