package android.support.v4.animation;

import android.support.v4.animation.ValueAnimatorCompat;

interface AnimatorProvider {
   ValueAnimatorCompat emptyValueAnimator();
}
