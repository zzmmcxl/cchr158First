package android.support.v4.widget;

interface DrawerLayoutImpl {
   void setChildInsets(Object var1, boolean var2);
}
