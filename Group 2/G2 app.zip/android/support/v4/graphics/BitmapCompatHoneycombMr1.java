package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatHoneycombMr1 {
   static int getAllocationByteCount(Bitmap var0) {
      return var0.getByteCount();
   }
}
