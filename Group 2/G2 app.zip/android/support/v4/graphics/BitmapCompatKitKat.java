package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatKitKat {
   static int getAllocationByteCount(Bitmap var0) {
      return var0.getAllocationByteCount();
   }
}
