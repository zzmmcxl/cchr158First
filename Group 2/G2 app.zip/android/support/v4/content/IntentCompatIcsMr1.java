package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1 {
   public static Intent makeMainSelectorActivity(String var0, String var1) {
      return Intent.makeMainSelectorActivity(var0, var1);
   }
}
