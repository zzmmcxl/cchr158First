package android.support.v4.widget;

import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.widget.TextView;

class TextViewCompatApi23
{
  public static void setTextAppearance(@NonNull TextView paramTextView, @StyleRes int paramInt)
  {
    paramTextView.setTextAppearance(paramInt);
  }
}


/* Location:              C:\Users\colin\Documents\GitHub\cchr158First\G7.jar!\android\support\v4\widget\TextViewCompatApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */