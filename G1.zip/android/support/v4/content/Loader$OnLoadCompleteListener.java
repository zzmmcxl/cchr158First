package android.support.v4.content;

public interface OnLoadCompleteListener<D>
{
    void onLoadComplete(final Loader<D> p0, final D p1);
}
