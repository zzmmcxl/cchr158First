package android.support.v4.content;

public interface OnLoadCanceledListener<D>
{
    void onLoadCanceled(final Loader<D> p0);
}
