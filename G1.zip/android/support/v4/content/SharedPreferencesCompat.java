package android.support.v4.content;

import android.support.annotation.NonNull;
import android.content.SharedPreferences$Editor;
import android.os.Build$VERSION;

public final class SharedPreferencesCompat
{
    private SharedPreferencesCompat() {
        super();
    }
}
