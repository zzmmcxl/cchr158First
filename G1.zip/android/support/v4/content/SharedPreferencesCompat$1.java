package android.support.v4.content;

static class SharedPreferencesCompat$1 {}