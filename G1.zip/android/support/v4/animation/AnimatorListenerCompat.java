package android.support.v4.animation;

public interface AnimatorListenerCompat
{
    void onAnimationCancel(final ValueAnimatorCompat p0);
    
    void onAnimationEnd(final ValueAnimatorCompat p0);
    
    void onAnimationRepeat(final ValueAnimatorCompat p0);
    
    void onAnimationStart(final ValueAnimatorCompat p0);
}
