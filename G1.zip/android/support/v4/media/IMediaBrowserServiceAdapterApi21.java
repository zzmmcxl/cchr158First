package android.support.v4.media;

import android.os.RemoteException;
import android.os.Parcel;
import android.os.ResultReceiver;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Binder;

class IMediaBrowserServiceAdapterApi21
{
    IMediaBrowserServiceAdapterApi21() {
        super();
    }
}
