package android.support.v4.media;

public class TransportStateListener
{
    public TransportStateListener() {
        super();
    }
    
    public void onPlayingChanged(final TransportController transportController) {
    }
    
    public void onTransportControlsChanged(final TransportController transportController) {
    }
}
