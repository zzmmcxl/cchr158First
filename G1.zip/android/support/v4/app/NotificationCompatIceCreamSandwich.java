package android.support.v4.app;

import android.graphics.Bitmap;
import android.app.PendingIntent;
import android.widget.RemoteViews;
import android.app.Notification;
import android.content.Context;
import android.app.Notification$Builder;

class NotificationCompatIceCreamSandwich
{
    NotificationCompatIceCreamSandwich() {
        super();
    }
}
