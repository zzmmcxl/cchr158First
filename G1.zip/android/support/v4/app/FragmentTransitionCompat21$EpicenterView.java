package android.support.v4.app;

import android.view.View;

public static class EpicenterView
{
    public View epicenter;
    
    public EpicenterView() {
        super();
    }
}
