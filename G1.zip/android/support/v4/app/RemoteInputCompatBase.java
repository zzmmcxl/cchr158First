package android.support.v4.app;

import android.os.Bundle;

class RemoteInputCompatBase
{
    RemoteInputCompatBase() {
        super();
    }
}
