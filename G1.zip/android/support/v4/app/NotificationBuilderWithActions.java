package android.support.v4.app;

interface NotificationBuilderWithActions
{
    void addAction(final NotificationCompatBase.Action p0);
}
