package android.support.v4.app;

public interface Extender
{
    NotificationCompat.Builder extend(final NotificationCompat.Builder p0);
}
