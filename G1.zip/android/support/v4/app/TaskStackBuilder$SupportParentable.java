package android.support.v4.app;

import android.content.Intent;

public interface SupportParentable
{
    Intent getSupportParentActivityIntent();
}
