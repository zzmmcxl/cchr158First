package android.support.v4.app;

import android.support.annotation.NonNull;

public interface OnRequestPermissionsResultCallback
{
    void onRequestPermissionsResult(final int p0, @NonNull final String[] p1, @NonNull final int[] p2);
}
