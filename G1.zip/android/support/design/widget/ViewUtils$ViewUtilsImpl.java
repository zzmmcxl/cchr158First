package android.support.design.widget;

import android.view.View;

private interface ViewUtilsImpl
{
    void setBoundsViewOutlineProvider(final View p0);
}
