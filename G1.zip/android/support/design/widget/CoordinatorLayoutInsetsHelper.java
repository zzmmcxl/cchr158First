package android.support.design.widget;

import android.support.v4.view.OnApplyWindowInsetsListener;
import android.view.View;

interface CoordinatorLayoutInsetsHelper
{
    void setupForWindowInsets(final View p0, final OnApplyWindowInsetsListener p1);
}
