package android.support.design.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

private interface ViewGroupUtilsImpl
{
    void offsetDescendantRect(final ViewGroup p0, final View p1, final Rect p2);
}
