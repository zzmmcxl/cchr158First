package android.support.design.widget;

class ValueAnimatorCompatImplEclairMr1$1 implements Runnable {
    final /* synthetic */ ValueAnimatorCompatImplEclairMr1 this$0;
    
    ValueAnimatorCompatImplEclairMr1$1(final ValueAnimatorCompatImplEclairMr1 this$0) {
        this$0 = this$0;
        super();
    }
    
    @Override
    public void run() {
        ValueAnimatorCompatImplEclairMr1.access$000(this$0);
    }
}