package android.support.design.widget;

interface AnimatorUpdateListener
{
    void onAnimationUpdate(final ValueAnimatorCompat p0);
}
