package android.support.design.widget;

import android.view.ViewTreeObserver$OnPreDrawListener;

class FloatingActionButtonImpl$1 implements ViewTreeObserver$OnPreDrawListener {
    final /* synthetic */ FloatingActionButtonImpl this$0;
    
    FloatingActionButtonImpl$1(final FloatingActionButtonImpl this$0) {
        this$0 = this$0;
        super();
    }
    
    public boolean onPreDraw() {
        this$0.onPreDraw();
        return true;
    }
}