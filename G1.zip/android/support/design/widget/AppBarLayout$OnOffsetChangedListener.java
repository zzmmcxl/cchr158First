package android.support.design.widget;

public interface OnOffsetChangedListener
{
    void onOffsetChanged(final AppBarLayout p0, final int p1);
}
