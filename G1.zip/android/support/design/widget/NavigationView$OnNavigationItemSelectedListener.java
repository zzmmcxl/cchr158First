package android.support.design.widget;

import android.view.MenuItem;

public interface OnNavigationItemSelectedListener
{
    boolean onNavigationItemSelected(final MenuItem p0);
}
