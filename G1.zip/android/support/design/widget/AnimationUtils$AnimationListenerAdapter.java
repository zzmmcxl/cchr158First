package android.support.design.widget;

import android.view.animation.Animation;
import android.view.animation.Animation$AnimationListener;

static class AnimationListenerAdapter implements Animation$AnimationListener
{
    AnimationListenerAdapter() {
        super();
    }
    
    public void onAnimationEnd(final Animation animation) {
    }
    
    public void onAnimationRepeat(final Animation animation) {
    }
    
    public void onAnimationStart(final Animation animation) {
    }
}
