package android.support.design.widget;

import android.view.View;

public interface OnDismissListener
{
    void onDismiss(final View p0);
    
    void onDragStateChanged(final int p0);
}
