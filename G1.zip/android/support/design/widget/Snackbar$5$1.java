package android.support.design.widget;

class Snackbar$5$1 implements Runnable {
    final /* synthetic */ Snackbar$5 this$1;
    
    Snackbar$5$1(final Snackbar$5 this$1) {
        this$1 = this$1;
        super();
    }
    
    @Override
    public void run() {
        Snackbar.access$300(this$0, 3);
    }
}