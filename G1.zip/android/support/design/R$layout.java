package android.support.design;

public static final class layout
{
    public static final int abc_action_bar_title_item = 2130968576;
    public static final int abc_action_bar_up_container = 2130968577;
    public static final int abc_action_bar_view_list_nav_layout = 2130968578;
    public static final int abc_action_menu_item_layout = 2130968579;
    public static final int abc_action_menu_layout = 2130968580;
    public static final int abc_action_mode_bar = 2130968581;
    public static final int abc_action_mode_close_item_material = 2130968582;
    public static final int abc_activity_chooser_view = 2130968583;
    public static final int abc_activity_chooser_view_list_item = 2130968584;
    public static final int abc_alert_dialog_button_bar_material = 2130968585;
    public static final int abc_alert_dialog_material = 2130968586;
    public static final int abc_dialog_title_material = 2130968587;
    public static final int abc_expanded_menu_layout = 2130968588;
    public static final int abc_list_menu_item_checkbox = 2130968589;
    public static final int abc_list_menu_item_icon = 2130968590;
    public static final int abc_list_menu_item_layout = 2130968591;
    public static final int abc_list_menu_item_radio = 2130968592;
    public static final int abc_popup_menu_item_layout = 2130968593;
    public static final int abc_screen_content_include = 2130968594;
    public static final int abc_screen_simple = 2130968595;
    public static final int abc_screen_simple_overlay_action_mode = 2130968596;
    public static final int abc_screen_toolbar = 2130968597;
    public static final int abc_search_dropdown_item_icons_2line = 2130968598;
    public static final int abc_search_view = 2130968599;
    public static final int abc_select_dialog_material = 2130968600;
    public static final int design_bottom_sheet_dialog = 2130968605;
    public static final int design_layout_snackbar = 2130968606;
    public static final int design_layout_snackbar_include = 2130968607;
    public static final int design_layout_tab_icon = 2130968608;
    public static final int design_layout_tab_text = 2130968609;
    public static final int design_menu_item_action_area = 2130968610;
    public static final int design_navigation_item = 2130968611;
    public static final int design_navigation_item_header = 2130968612;
    public static final int design_navigation_item_separator = 2130968613;
    public static final int design_navigation_item_subheader = 2130968614;
    public static final int design_navigation_menu = 2130968615;
    public static final int design_navigation_menu_item = 2130968616;
    public static final int notification_media_action = 2130968617;
    public static final int notification_media_cancel_action = 2130968618;
    public static final int notification_template_big_media = 2130968619;
    public static final int notification_template_big_media_narrow = 2130968620;
    public static final int notification_template_lines = 2130968621;
    public static final int notification_template_media = 2130968622;
    public static final int notification_template_part_chronometer = 2130968623;
    public static final int notification_template_part_time = 2130968624;
    public static final int select_dialog_item_material = 2130968625;
    public static final int select_dialog_multichoice_material = 2130968626;
    public static final int select_dialog_singlechoice_material = 2130968627;
    public static final int support_simple_spinner_dropdown_item = 2130968629;
    
    public layout() {
        super();
    }
}
