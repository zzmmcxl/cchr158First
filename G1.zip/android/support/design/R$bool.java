package android.support.design;

public static final class bool
{
    public static final int abc_action_bar_embed_tabs = 2131165187;
    public static final int abc_action_bar_embed_tabs_pre_jb = 2131165185;
    public static final int abc_action_bar_expanded_action_views_exclusive = 2131165188;
    public static final int abc_allow_stacked_button_bar = 2131165184;
    public static final int abc_config_actionMenuItemAllCaps = 2131165189;
    public static final int abc_config_allowActionMenuItemTextWithIcon = 2131165186;
    public static final int abc_config_closeDialogWhenTouchOutside = 2131165190;
    public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131165191;
    
    public bool() {
        super();
    }
}
