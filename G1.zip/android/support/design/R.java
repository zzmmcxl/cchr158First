package android.support.design;

public final class R
{
    public R() {
        super();
    }
}
