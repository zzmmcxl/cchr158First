package android.support.design;

public static final class string
{
    public static final int abc_action_bar_home_description = 2131099648;
    public static final int abc_action_bar_home_description_format = 2131099649;
    public static final int abc_action_bar_home_subtitle_description_format = 2131099650;
    public static final int abc_action_bar_up_description = 2131099651;
    public static final int abc_action_menu_overflow_description = 2131099652;
    public static final int abc_action_mode_done = 2131099653;
    public static final int abc_activity_chooser_view_see_all = 2131099654;
    public static final int abc_activitychooserview_choose_application = 2131099655;
    public static final int abc_capital_off = 2131099656;
    public static final int abc_capital_on = 2131099657;
    public static final int abc_search_hint = 2131099658;
    public static final int abc_searchview_description_clear = 2131099659;
    public static final int abc_searchview_description_query = 2131099660;
    public static final int abc_searchview_description_search = 2131099661;
    public static final int abc_searchview_description_submit = 2131099662;
    public static final int abc_searchview_description_voice = 2131099663;
    public static final int abc_shareactionprovider_share_with = 2131099664;
    public static final int abc_shareactionprovider_share_with_application = 2131099665;
    public static final int abc_toolbar_collapse_description = 2131099666;
    public static final int appbar_scrolling_view_behavior = 2131099670;
    public static final int bottom_sheet_behavior = 2131099671;
    public static final int character_counter_pattern = 2131099673;
    public static final int status_bar_notification_info_overflow = 2131099667;
    
    public string() {
        super();
    }
}
