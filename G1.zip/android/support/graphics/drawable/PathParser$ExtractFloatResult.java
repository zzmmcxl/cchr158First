package android.support.graphics.drawable;

private static class ExtractFloatResult
{
    int mEndPosition;
    boolean mEndWithNegOrDot;
    
    private ExtractFloatResult() {
        super();
    }
    
    ExtractFloatResult(final PathParser$1 object) {
        this();
    }
}
