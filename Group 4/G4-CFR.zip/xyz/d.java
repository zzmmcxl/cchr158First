/*
 * Decompiled with CFR 0_115.
 */
package xyz;

import xyz.a;
import xyz.c;

public class d {
    private int a;
    private String b;
    private String c;

    public d() {
    }

    public d(String string, String string2) {
        this.b = string;
        this.c = string2;
    }

    public String a() {
        return this.b;
    }

    public void a(a a2) {
        this.b = (String)a2.a(0);
    }

    public String b() {
        return this.c;
    }

    public void b(a a2) {
        this.a = (Integer)a2.a(0);
    }

    public void c(a a2) {
        this.c = (String)a2.a(0);
    }

    public String toString() {
        return "Task [id=" + this.a + c.a("+OuX4tfPNzS96tpY4hyLtA==") + this.b + c.a("OOoLMTIFjBK8jypAbZr+DA==") + this.c + c.a("6xDWm6oAV06WLJr4TjMf9Q==");
    }
}

