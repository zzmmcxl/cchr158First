/*
 * Decompiled with CFR 0_115.
 */
package xyz;

public class b {
    public static String a = "qktsccxutnfzlzbdoujgxjgodkejtzxtrlrczmdpuypreophdivwyfwafyfqyqfy";
    public static String b = "gfjkowzrwvzvgxmryvbiqbmdfrtcmfwglaqfjxitptsmndhfltkqhqopkvsmwukm";
    public static String c = "ibrvvzixodpwqphxlzngscbxwihpzbvuixtyvivmniqfazurqcivxssntdqaysaj";
    public static String d = "glsjxrjutikvmfupmqxnillimafebemrmshuojelkpvluqdclhddcmulzgnlkonv";
    public static String e = "sdsjjaqqfqoxpusoikgkqffvvhvhigwtqbqvfyjggmdnzgzdzkorfilirukiggfr";
    public static String f = "jyetxenxarqmnfycdqzrwigrljkmrprtczayxjzqjnhgkkrxthrjhaqkioyqkref";
    public static String g = "ablyicixozhtqgilaylctxfbshejcklwzdfmhspeedptexxuerslgfxtpzvttxyd";
    public static String h = "hxfvsjjkmfkhyafzueexjewwnkyzukvakmgpzfvqfcyejcvwrjyvnmcvmsjwtrlb";
    public static String i = "hmtyrjywukluovrzxqscsftwjuentiqpgxnirscxrlbabldyojghgocjdxcergli";
    public static String j = "tuwuzzuoyybriyseuznteaolekngbomesaahgekwgzndltfdfndizbuvuxygaktr";
    public static String k = "vfpfxtuatxcidvyfdekrhswcrtcuaeckkqjczxownjgmtvkjodiqihxwcjcvaqqj";
    public static String l = "jgemucirsdbvsnsmyoktocrdajlvzgqxoiyxxwokdliaamihtddxfkytiurfcyap";
    public static String m = "vhflerwwtswmfoiakfowzrwkysnnqchppgrrahasatvctclungrrndzlibtnkaqe";
    public static String n = "cyxodoroxfoawqsxffkeumtkybjslwlzlniflwuyuadwsgmxunmrepyyavtdpmpn";
    public static String o = "kbasnvpgtabxjakzmspaooufcpjpclkfxbgbcpmiflblmyzrtitxqdncpsdnnucn";
    public static String p = "zybjyekfabgiyoowcbjqdueznzcnabmcwzvygfeuvpsrkcheuytvkrsmoiokbyub";
    public static String q = "jbussqyoccgdcfcawgwqqjwnskzggwdxdwkyeaqtmnsauafrwyrsjhjmyduryhto";
    public static String r = "zrjlejgpqbkeygpdpdczitnhfxuskkawoxqnuqcmvcfvpgjnrybhgfyxqhghdzps";
    public static String s = "gimibvhkrdnekmywcptdxaagppiuscssakwyvgmsypqlwwdwghxqqxaznwwifyjk";
    public static String t = "rcadpekpikjzfqgtrhisclhydvdisseuqzcltfsecfojdplmdbkmoohnuxiromwx";
    public static String u = "haucfvuctakrrsqdcojuqnendehtuanjxpbrkbjfcagvgyxxsxbjqysbntxkojvq";
    public static String v = "lmqvbaqaeedzkhzxupmklsbxdmlebkmtedwarcjrplbyztrploneedbzbvbyshzn";
    public static String w = "cwvndjoxxbdrfsofeptebncegzzjdrctvotuywrxtwxsijgeuzeeywowkxdrjspa";
    public static String x = "zsubmozugewdcfjnzsfxyqggjshaorcscujndihszucjzgcwpfwiknxhdwoocmxd";
    public static String y = "xyxtfctkgahtryccbvrtktjxgtxvfeygiysrwzfjeifnfqmyclzideubialyqfqm";
}

