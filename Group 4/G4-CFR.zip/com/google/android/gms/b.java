/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms;

public final class b {
    public static final int adjust_height = 2131558453;
    public static final int adjust_width = 2131558454;
    public static final int android_pay = 2131558496;
    public static final int android_pay_dark = 2131558487;
    public static final int android_pay_light = 2131558488;
    public static final int android_pay_light_with_border = 2131558489;
    public static final int auto = 2131558466;
    public static final int book_now = 2131558480;
    public static final int buyButton = 2131558477;
    public static final int buy_now = 2131558481;
    public static final int buy_with = 2131558482;
    public static final int buy_with_google = 2131558483;
    public static final int cast_notification_id = 2131558404;
    public static final int classic = 2131558490;
    public static final int dark = 2131558467;
    public static final int donate_with = 2131558484;
    public static final int donate_with_google = 2131558485;
    public static final int google_wallet_classic = 2131558491;
    public static final int google_wallet_grayscale = 2131558492;
    public static final int google_wallet_monochrome = 2131558493;
    public static final int grayscale = 2131558494;
    public static final int holo_dark = 2131558471;
    public static final int holo_light = 2131558472;
    public static final int hybrid = 2131558455;
    public static final int icon_only = 2131558463;
    public static final int light = 2131558468;
    public static final int logo_only = 2131558486;
    public static final int match_parent = 2131558479;
    public static final int monochrome = 2131558495;
    public static final int none = 2131558417;
    public static final int normal = 2131558413;
    public static final int place_autocomplete_clear_button = 2131558587;
    public static final int place_autocomplete_powered_by_google = 2131558589;
    public static final int place_autocomplete_prediction_primary_text = 2131558591;
    public static final int place_autocomplete_prediction_secondary_text = 2131558592;
    public static final int place_autocomplete_progress = 2131558590;
    public static final int place_autocomplete_search_button = 2131558585;
    public static final int place_autocomplete_search_input = 2131558586;
    public static final int place_autocomplete_separator = 2131558588;
    public static final int production = 2131558473;
    public static final int sandbox = 2131558474;
    public static final int satellite = 2131558456;
    public static final int selectionDetails = 2131558478;
    public static final int slide = 2131558449;
    public static final int standard = 2131558464;
    public static final int strict_sandbox = 2131558475;
    public static final int terrain = 2131558457;
    public static final int test = 2131558476;
    public static final int wide = 2131558465;
    public static final int wrap_content = 2131558427;
}

