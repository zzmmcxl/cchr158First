/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms;

public final class c {
    public static final int place_autocomplete_fragment = 2130968627;
    public static final int place_autocomplete_item_powered_by_google = 2130968628;
    public static final int place_autocomplete_item_prediction = 2130968629;
    public static final int place_autocomplete_progress = 2130968630;
}

