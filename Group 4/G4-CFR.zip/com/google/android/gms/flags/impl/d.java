/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.b.ky;
import com.google.android.gms.flags.impl.a;
import com.google.android.gms.flags.impl.e;

public class d
extends a {
    public static Integer a(SharedPreferences sharedPreferences, String string, Integer n2) {
        return (Integer)ky.a(new e(sharedPreferences, string, n2));
    }
}

