/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.b.ky;
import com.google.android.gms.flags.impl.a;
import com.google.android.gms.flags.impl.i;

public class h
extends a {
    public static String a(SharedPreferences sharedPreferences, String string, String string2) {
        return (String)ky.a(new i(sharedPreferences, string, string2));
    }
}

