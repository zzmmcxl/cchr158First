/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location;

public interface q {
}

