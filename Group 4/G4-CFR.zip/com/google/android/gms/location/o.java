/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location;

import com.google.android.gms.common.api.i;
import com.google.android.gms.common.api.internal.c;
import com.google.android.gms.common.api.n;
import com.google.android.gms.location.m;

public abstract class o
extends c {
    public o(n n2) {
        super(m.a(), n2);
    }
}

