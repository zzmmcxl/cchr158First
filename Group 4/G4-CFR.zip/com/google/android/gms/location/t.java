/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location;

import android.os.IInterface;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationResult;

public interface t
extends IInterface {
    public void a(LocationAvailability var1);

    public void a(LocationResult var1);
}

