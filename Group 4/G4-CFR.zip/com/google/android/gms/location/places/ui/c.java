/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.places.ui;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.a;

public interface c {
    public void a(Status var1);

    public void a(a var1);
}

