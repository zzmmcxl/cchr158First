/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.places.ui;

import android.view.View;
import com.google.android.gms.location.places.ui.SupportPlaceAutocompleteFragment;

class d
implements View.OnClickListener {
    final /* synthetic */ SupportPlaceAutocompleteFragment a;

    d(SupportPlaceAutocompleteFragment supportPlaceAutocompleteFragment) {
        this.a = supportPlaceAutocompleteFragment;
    }

    public void onClick(View view) {
        SupportPlaceAutocompleteFragment.a(this.a);
    }
}

