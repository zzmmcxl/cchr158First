/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.places.ui;

import android.content.Context;
import android.content.Intent;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.ui.f;

public class a
extends f {
    public static com.google.android.gms.location.places.a a(Context context, Intent intent) {
        return f.c(context, intent);
    }

    public static Status b(Context context, Intent intent) {
        return f.d(context, intent);
    }
}

