/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.places;

import com.google.android.gms.maps.model.LatLng;

public interface a {
    public CharSequence a();

    public CharSequence b();

    public LatLng c();
}

