/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

import android.os.IInterface;
import com.google.android.gms.location.internal.a;
import com.google.android.gms.location.internal.ac;
import com.google.android.gms.location.internal.o;

class b
implements ac {
    final /* synthetic */ a a;

    b(a a2) {
        this.a = a2;
    }

    @Override
    public void a() {
        a.a(this.a);
    }

    public o b() {
        return (o)this.a.r();
    }

    @Override
    public /* synthetic */ IInterface c() {
        return this.b();
    }
}

