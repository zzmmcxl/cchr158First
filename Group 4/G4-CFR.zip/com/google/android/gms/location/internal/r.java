/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

import android.os.IInterface;
import com.google.android.gms.location.LocationSettingsResult;

public interface r
extends IInterface {
    public void a(LocationSettingsResult var1);
}

