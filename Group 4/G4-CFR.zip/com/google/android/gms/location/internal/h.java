/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.n;
import com.google.android.gms.common.api.w;
import com.google.android.gms.location.o;

abstract class h
extends o {
    public h(n n2) {
        super(n2);
    }

    public Status a(Status status) {
        return status;
    }

    @Override
    public /* synthetic */ w b(Status status) {
        return this.a(status);
    }
}

