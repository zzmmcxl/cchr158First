/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

import com.google.android.gms.location.q;

public class ad
implements q {
}

