/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

public class d
implements com.google.android.gms.location.d {
}

