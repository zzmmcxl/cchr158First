/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location.internal;

import android.os.IInterface;
import com.google.android.gms.location.internal.FusedLocationProviderResult;

public interface i
extends IInterface {
    public void a(FusedLocationProviderResult var1);
}

