/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location;

import android.app.PendingIntent;
import com.google.android.gms.common.api.n;
import com.google.android.gms.common.api.t;
import com.google.android.gms.location.GeofencingRequest;

public interface g {
    public t a(n var1, GeofencingRequest var2, PendingIntent var3);
}

