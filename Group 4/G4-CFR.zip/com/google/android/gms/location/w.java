/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.location;

import android.location.Location;
import android.os.IInterface;

public interface w
extends IInterface {
    public void a(Location var1);
}

