/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common;

public final class c
extends Exception {
    public final int a;

    public c(int n2) {
        this.a = n2;
    }
}

