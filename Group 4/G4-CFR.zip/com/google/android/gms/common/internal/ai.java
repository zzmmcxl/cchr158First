/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.os.Bundle;

public interface ai {
    public Bundle b_();

    public boolean h();
}

