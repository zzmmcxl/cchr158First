/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import java.util.Set;

public final class u {
    public final Set a;
    public final boolean b;
}

