/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

public class f {
    public static final boolean a = f.a();

    private static final boolean a() {
        return false;
    }
}

