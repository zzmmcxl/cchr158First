/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import com.google.android.gms.common.internal.bf;
import com.google.android.gms.common.internal.g;

final class r
extends g {
    r() {
    }

    @Override
    public g a(g g2) {
        bf.a(g2);
        return this;
    }

    @Override
    public boolean b(char c2) {
        return true;
    }

    @Override
    public boolean b(CharSequence charSequence) {
        bf.a(charSequence);
        return true;
    }
}

