/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.internal.GetServiceRequest;
import com.google.android.gms.common.internal.ValidateAccountRequest;
import com.google.android.gms.common.internal.at;

public interface aw
extends IInterface {
    public void a();

    public void a(at var1, int var2);

    public void a(at var1, int var2, String var3);

    public void a(at var1, int var2, String var3, Bundle var4);

    public void a(at var1, int var2, String var3, IBinder var4, Bundle var5);

    public void a(at var1, int var2, String var3, String var4);

    public void a(at var1, int var2, String var3, String var4, String var5, String[] var6);

    public void a(at var1, int var2, String var3, String var4, String[] var5);

    public void a(at var1, int var2, String var3, String var4, String[] var5, Bundle var6);

    public void a(at var1, int var2, String var3, String var4, String[] var5, String var6, Bundle var7);

    public void a(at var1, int var2, String var3, String var4, String[] var5, String var6, IBinder var7, String var8, Bundle var9);

    public void a(at var1, int var2, String var3, String[] var4, String var5, Bundle var6);

    public void a(at var1, GetServiceRequest var2);

    public void a(at var1, ValidateAccountRequest var2);

    public void b(at var1, int var2, String var3);

    public void b(at var1, int var2, String var3, Bundle var4);

    public void c(at var1, int var2, String var3);

    public void c(at var1, int var2, String var3, Bundle var4);

    public void d(at var1, int var2, String var3);

    public void d(at var1, int var2, String var3, Bundle var4);

    public void e(at var1, int var2, String var3);

    public void e(at var1, int var2, String var3, Bundle var4);

    public void f(at var1, int var2, String var3);

    public void f(at var1, int var2, String var3, Bundle var4);

    public void g(at var1, int var2, String var3);

    public void g(at var1, int var2, String var3, Bundle var4);

    public void h(at var1, int var2, String var3);

    public void h(at var1, int var2, String var3, Bundle var4);

    public void i(at var1, int var2, String var3);

    public void i(at var1, int var2, String var3, Bundle var4);

    public void j(at var1, int var2, String var3);

    public void j(at var1, int var2, String var3, Bundle var4);

    public void k(at var1, int var2, String var3);

    public void k(at var1, int var2, String var3, Bundle var4);

    public void l(at var1, int var2, String var3);

    public void l(at var1, int var2, String var3, Bundle var4);

    public void m(at var1, int var2, String var3);

    public void m(at var1, int var2, String var3, Bundle var4);

    public void n(at var1, int var2, String var3, Bundle var4);

    public void o(at var1, int var2, String var3, Bundle var4);

    public void p(at var1, int var2, String var3, Bundle var4);

    public void q(at var1, int var2, String var3, Bundle var4);

    public void r(at var1, int var2, String var3, Bundle var4);

    public void s(at var1, int var2, String var3, Bundle var4);

    public void t(at var1, int var2, String var3, Bundle var4);
}

