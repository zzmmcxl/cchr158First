/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import com.google.android.gms.common.internal.g;

final class p
extends g {
    p() {
    }

    @Override
    public boolean b(char c2) {
        return Character.isUpperCase(c2);
    }
}

