/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;

public interface at
extends IInterface {
    public void a(int var1, Bundle var2);

    public void a(int var1, IBinder var2, Bundle var3);
}

