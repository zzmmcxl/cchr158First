/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.os.IInterface;
import com.google.android.gms.common.internal.ResolveAccountResponse;

public interface az
extends IInterface {
    public void a(ResolveAccountResponse var1);
}

