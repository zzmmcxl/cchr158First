/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

public final class d {
    public static void a(Object object) {
        if (object != null) return;
        throw new IllegalArgumentException("null reference");
    }
}

