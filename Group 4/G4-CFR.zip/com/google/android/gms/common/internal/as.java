/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.internal;

import android.os.IInterface;

public interface as
extends IInterface {
    public void a();
}

