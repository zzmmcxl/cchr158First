/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common;

import com.google.android.gms.common.l;
import com.google.android.gms.common.n;

final class q
extends n {
    q(byte[] arrby) {
        super(arrby);
    }

    @Override
    protected byte[] b() {
        return l.a("longStr3[0\u0082\u0004\u00a80\u0082\u0003\u0090\u00a0\u0003]");
    }
}

