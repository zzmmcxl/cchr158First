/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common;

import com.google.android.gms.common.l;
import com.google.android.gms.common.n;

final class p
extends n {
    p(byte[] arrby) {
        super(arrby);
    }

    @Override
    protected byte[] b() {
        return l.a("longStr2[0\u0082\u0004C0\u0082\u0003+\u00a0\u0003]");
    }
}

