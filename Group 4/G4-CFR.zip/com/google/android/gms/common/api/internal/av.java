/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

public final class av {
    private volatile Object a;

    public void a() {
        this.a = null;
    }
}

