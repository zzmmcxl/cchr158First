/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import android.os.IBinder;
import android.os.IInterface;

public interface j {
    public IInterface a(IBinder var1);

    public String a();

    public void a(int var1, IInterface var2);

    public String b();
}

