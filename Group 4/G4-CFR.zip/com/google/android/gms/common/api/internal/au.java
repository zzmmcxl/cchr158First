/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

public interface au {
    public void a(int var1, boolean var2);

    public void a(Bundle var1);

    public void a(ConnectionResult var1);
}

