/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.common.api.s;
import com.google.android.gms.common.internal.ap;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Set;

public interface h {
    public void a(s var1);

    public void a(ap var1, Set var2);

    public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

    public boolean d();

    public Intent e();

    public void g();

    public boolean h();

    public boolean i();

    public IBinder j();
}

