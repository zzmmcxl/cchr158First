/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import com.google.android.gms.common.api.internal.ak;
import com.google.android.gms.common.api.internal.al;
import com.google.android.gms.common.api.internal.am;
import com.google.android.gms.common.api.internal.au;
import com.google.android.gms.common.api.internal.l;

class n
extends am {
    final /* synthetic */ l a;

    n(l l2, ak ak2) {
        this.a = l2;
        super(ak2);
    }

    @Override
    public void a() {
        l.a((l)this.a).h.a((Bundle)null);
    }
}

