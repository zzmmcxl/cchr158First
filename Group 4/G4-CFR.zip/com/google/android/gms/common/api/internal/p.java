/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.content.Context;
import com.google.android.gms.common.api.internal.o;

class p
implements Runnable {
    final /* synthetic */ o a;

    p(o o2) {
        this.a = o2;
    }

    @Override
    public void run() {
        o.b(this.a).c(o.a(this.a));
    }
}

