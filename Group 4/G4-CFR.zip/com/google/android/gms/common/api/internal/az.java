/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.e;
import com.google.android.gms.common.api.n;
import com.google.android.gms.common.api.w;

public class az
extends e {
    public az(n n2) {
        super(n2);
    }

    protected Status a(Status status) {
        return status;
    }

    @Override
    protected /* synthetic */ w b(Status status) {
        return this.a(status);
    }
}

