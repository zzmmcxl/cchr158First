/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import com.google.android.gms.common.api.internal.z;
import com.google.android.gms.common.internal.ai;

class ab
implements ai {
    final /* synthetic */ z a;

    ab(z z2) {
        this.a = z2;
    }

    @Override
    public Bundle b_() {
        return null;
    }

    @Override
    public boolean h() {
        return this.a.i();
    }
}

