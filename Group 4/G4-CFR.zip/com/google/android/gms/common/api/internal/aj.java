/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.h;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.api.internal.ai;

interface aj {
    public Integer a();

    public void a(ai var1);

    public i b();

    public void b(h var1);

    public void c();

    public void c(Status var1);

    public void d(Status var1);

    public boolean e();

    public void f();

    public void g();
}

