/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.internal.c;

public interface ak {
    public c a(c var1);

    public void a();

    public void a(int var1);

    public void a(Bundle var1);

    public void a(ConnectionResult var1, a var2, int var3);

    public boolean b();

    public void c();
}

