/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

public interface d {
    public void a(Object var1);
}

