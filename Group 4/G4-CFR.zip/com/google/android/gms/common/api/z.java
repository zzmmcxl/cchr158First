/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.t;
import com.google.android.gms.common.api.w;

public abstract class z {
    public Status a(Status status) {
        return status;
    }

    public abstract t a(w var1);
}

