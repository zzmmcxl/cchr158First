/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

public abstract class ab {
    private static final Map a = new WeakHashMap();
    private static final Object b = new Object();

    public abstract void a(int var1);
}

