/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.w;
import com.google.android.gms.common.api.x;

public abstract class y
implements x {
    public abstract void a(Status var1);

    public abstract void b(w var1);
}

