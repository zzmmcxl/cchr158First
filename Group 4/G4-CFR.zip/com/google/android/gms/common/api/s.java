/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.ConnectionResult;

public interface s {
    public void a(ConnectionResult var1);
}

