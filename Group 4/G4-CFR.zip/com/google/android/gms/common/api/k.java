/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.api.j;

public interface k {
    public int a();

    public j a(Object var1);

    public int b();
}

