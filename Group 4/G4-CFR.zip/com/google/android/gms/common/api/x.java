/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import com.google.android.gms.common.api.w;

public interface x {
    public void a(w var1);
}

