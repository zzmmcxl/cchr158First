/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.api.internal.ak;
import com.google.android.gms.common.api.internal.am;
import com.google.android.gms.common.api.internal.l;

class m
extends am {
    final /* synthetic */ l a;

    m(l l2, ak ak2) {
        this.a = l2;
        super(ak2);
    }

    @Override
    public void a() {
        this.a.a(1);
    }
}

