/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import android.os.IInterface;
import com.google.android.gms.common.api.Status;

public interface aq
extends IInterface {
    public void a(Status var1);
}

