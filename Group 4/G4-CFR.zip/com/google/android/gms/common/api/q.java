/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api;

import android.os.Bundle;

public interface q {
    public void a(int var1);

    public void a(Bundle var1);
}

