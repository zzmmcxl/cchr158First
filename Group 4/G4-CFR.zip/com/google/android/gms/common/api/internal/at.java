/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.api.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.internal.ay;
import com.google.android.gms.common.api.internal.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public interface at {
    public c a(c var1);

    public void a();

    public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

    public boolean a(ay var1);

    public ConnectionResult b();

    public boolean c();

    public boolean d();

    public void f();

    public void g();
}

