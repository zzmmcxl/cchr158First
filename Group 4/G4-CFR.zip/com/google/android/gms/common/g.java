/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common;

import android.content.Intent;

public class g
extends Exception {
    private final Intent a;

    public g(String string, Intent intent) {
        super(string);
        this.a = intent;
    }
}

