/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.stats;

import com.google.android.gms.b.je;
import com.google.android.gms.common.stats.f;

public final class e {
    public static je a = je.a("gms:common:stats:wakeLocks:level", f.b);
    public static je b = je.a("gms:common:stats:wakelocks:time_out_duration", 600000);
}

