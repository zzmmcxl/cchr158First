/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.stats;

import android.content.ComponentName;

public final class f {
    public static final ComponentName a = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
    public static int b = 0;
    public static int c = 1;
    public static int d = 2;
    public static int e = 4;
    public static int f = 8;
    public static int g = 16;
    public static int h = 32;
    public static int i = 1;
}

