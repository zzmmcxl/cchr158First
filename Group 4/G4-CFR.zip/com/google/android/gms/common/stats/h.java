/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.stats;

public abstract class h {
    public abstract long a();

    public abstract int b();

    public abstract long i();

    public abstract String l();

    public String toString() {
        return "" + this.a() + "\t" + this.b() + "\t" + this.i() + this.l();
    }
}

