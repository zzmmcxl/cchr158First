/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common.stats;

import com.google.android.gms.b.je;

public final class c {
    public static je a = je.a("gms:common:stats:max_num_of_events", 100);
    public static je b = je.a("gms:common:stats:max_chunk_size", 100);
}

