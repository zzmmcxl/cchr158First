/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.common;

import android.content.Intent;
import com.google.android.gms.common.g;

public class d
extends g {
    private final int a;

    d(int n2, String string, Intent intent) {
        super(string, intent);
        this.a = n2;
    }

    public int a() {
        return this.a;
    }
}

