/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.signin.internal;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.signin.internal.AuthAccountResult;
import com.google.android.gms.signin.internal.SignInResponse;
import com.google.android.gms.signin.internal.e;

public class b
extends e {
    @Override
    public void a(ConnectionResult connectionResult, AuthAccountResult authAccountResult) {
    }

    @Override
    public void a(Status status) {
    }

    @Override
    public void a(Status status, GoogleSignInAccount googleSignInAccount) {
    }

    @Override
    public void a(SignInResponse signInResponse) {
    }

    @Override
    public void b(Status status) {
    }
}

