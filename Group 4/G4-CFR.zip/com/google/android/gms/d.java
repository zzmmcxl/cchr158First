/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms;

public final class d {
    public static final int accept = 2131165247;
    public static final int auth_google_play_services_client_facebook_display_name = 2131165249;
    public static final int auth_google_play_services_client_google_display_name = 2131165250;
    public static final int cast_notification_connected_message = 2131165252;
    public static final int cast_notification_connecting_message = 2131165253;
    public static final int cast_notification_disconnect = 2131165254;
    public static final int common_google_play_services_api_unavailable_text = 2131165203;
    public static final int common_google_play_services_enable_button = 2131165204;
    public static final int common_google_play_services_enable_text = 2131165205;
    public static final int common_google_play_services_enable_title = 2131165206;
    public static final int common_google_play_services_install_button = 2131165207;
    public static final int common_google_play_services_install_text_phone = 2131165208;
    public static final int common_google_play_services_install_text_tablet = 2131165209;
    public static final int common_google_play_services_install_title = 2131165210;
    public static final int common_google_play_services_invalid_account_text = 2131165211;
    public static final int common_google_play_services_invalid_account_title = 2131165212;
    public static final int common_google_play_services_network_error_text = 2131165213;
    public static final int common_google_play_services_network_error_title = 2131165214;
    public static final int common_google_play_services_notification_ticker = 2131165215;
    public static final int common_google_play_services_restricted_profile_text = 2131165216;
    public static final int common_google_play_services_restricted_profile_title = 2131165217;
    public static final int common_google_play_services_sign_in_failed_text = 2131165218;
    public static final int common_google_play_services_sign_in_failed_title = 2131165219;
    public static final int common_google_play_services_unknown_issue = 2131165220;
    public static final int common_google_play_services_unsupported_text = 2131165221;
    public static final int common_google_play_services_unsupported_title = 2131165222;
    public static final int common_google_play_services_update_button = 2131165223;
    public static final int common_google_play_services_update_text = 2131165224;
    public static final int common_google_play_services_update_title = 2131165225;
    public static final int common_google_play_services_updating_text = 2131165226;
    public static final int common_google_play_services_updating_title = 2131165227;
    public static final int common_google_play_services_wear_update_text = 2131165228;
    public static final int common_open_on_phone = 2131165229;
    public static final int common_signin_button_text = 2131165230;
    public static final int common_signin_button_text_long = 2131165231;
    public static final int create_calendar_message = 2131165256;
    public static final int create_calendar_title = 2131165257;
    public static final int decline = 2131165258;
    public static final int place_autocomplete_clear_button = 2131165243;
    public static final int place_autocomplete_search_hint = 2131165244;
    public static final int store_picture_message = 2131165260;
    public static final int store_picture_title = 2131165261;
    public static final int wallet_buy_button_place_holder = 2131165246;
}

