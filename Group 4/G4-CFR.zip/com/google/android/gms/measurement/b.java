/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement;

import android.os.Bundle;

public interface b {
    public void a(String var1, String var2, Bundle var3, long var4);
}

