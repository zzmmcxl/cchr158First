/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement;

import com.google.android.gms.common.internal.bf;
import com.google.android.gms.measurement.internal.bx;

public class a {
    private final bx a;

    public a(bx bx2) {
        bf.a(bx2);
        this.a = bx2;
    }
}

