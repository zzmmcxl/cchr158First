/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.u;
import com.google.android.gms.measurement.internal.v;

class w
implements Runnable {
    final /* synthetic */ v a;

    w(v v2) {
        this.a = v2;
    }

    @Override
    public void run() {
        this.a.a.v();
    }
}

