/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

interface bh {
    public void a(String var1, int var2, Throwable var3, byte[] var4);
}

