/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.ao;
import com.google.android.gms.measurement.internal.bc;
import com.google.android.gms.measurement.internal.be;
import com.google.android.gms.measurement.internal.bx;
import com.google.android.gms.measurement.internal.i;

class k
extends ao {
    final /* synthetic */ i a;

    k(i i2, bx bx2) {
        this.a = i2;
        super(bx2);
    }

    @Override
    public void a() {
        this.a.s().c().a("Tasks have been queued for a long time");
    }
}

