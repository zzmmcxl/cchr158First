/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.d;

class e
implements Runnable {
    final /* synthetic */ boolean a;
    final /* synthetic */ d b;

    @Override
    public void run() {
        d.a(this.b, this.a);
    }
}

