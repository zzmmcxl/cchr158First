/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.b.ln;
import com.google.android.gms.b.lq;

interface am {
    public void a(lq var1);

    public boolean a(long var1, ln var3);
}

