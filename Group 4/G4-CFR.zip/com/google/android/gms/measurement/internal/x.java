/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.ao;
import com.google.android.gms.measurement.internal.bx;
import com.google.android.gms.measurement.internal.u;

class x
extends ao {
    final /* synthetic */ u a;

    x(u u2, bx bx2) {
        this.a = u2;
        super(bx2);
    }

    @Override
    public void a() {
        u.a(this.a);
    }
}

