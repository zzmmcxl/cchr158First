/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import android.content.Context;
import com.google.android.gms.b.kf;
import com.google.android.gms.b.kh;
import com.google.android.gms.measurement.a;
import com.google.android.gms.measurement.internal.ad;
import com.google.android.gms.measurement.internal.ag;
import com.google.android.gms.measurement.internal.ai;
import com.google.android.gms.measurement.internal.aj;
import com.google.android.gms.measurement.internal.ak;
import com.google.android.gms.measurement.internal.aq;
import com.google.android.gms.measurement.internal.ba;
import com.google.android.gms.measurement.internal.bc;
import com.google.android.gms.measurement.internal.bf;
import com.google.android.gms.measurement.internal.bk;
import com.google.android.gms.measurement.internal.bn;
import com.google.android.gms.measurement.internal.bs;
import com.google.android.gms.measurement.internal.bt;
import com.google.android.gms.measurement.internal.bx;
import com.google.android.gms.measurement.internal.d;
import com.google.android.gms.measurement.internal.i;
import com.google.android.gms.measurement.internal.u;

class c {
    final Context a;

    c(Context context) {
        com.google.android.gms.common.internal.bf.a((Object)context);
        Context context2 = context.getApplicationContext();
        com.google.android.gms.common.internal.bf.a((Object)context2);
        this.a = context2;
    }

    aj a(bx bx2) {
        return new aj(bx2);
    }

    public bx a() {
        return new bx(this);
    }

    bn b(bx bx2) {
        return new bn(bx2);
    }

    bc c(bx bx2) {
        return new bc(bx2);
    }

    bt d(bx bx2) {
        return new bt(bx2);
    }

    u e(bx bx2) {
        return new u(bx2);
    }

    bs f(bx bx2) {
        return new bs(bx2);
    }

    a g(bx bx2) {
        return new a(bx2);
    }

    d h(bx bx2) {
        return new d(bx2);
    }

    ag i(bx bx2) {
        return new ag(bx2);
    }

    ak j(bx bx2) {
        return new ak(bx2);
    }

    bf k(bx bx2) {
        return new bf(bx2);
    }

    kf l(bx bx2) {
        return kh.c();
    }

    i m(bx bx2) {
        return new i(bx2);
    }

    aq n(bx bx2) {
        return new aq(bx2);
    }

    ba o(bx bx2) {
        return new ba(bx2);
    }

    bk p(bx bx2) {
        return new bk(bx2);
    }

    ad q(bx bx2) {
        return new ad(bx2);
    }

    ai r(bx bx2) {
        return new ai(bx2);
    }
}

