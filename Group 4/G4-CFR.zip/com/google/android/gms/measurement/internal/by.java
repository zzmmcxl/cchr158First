/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.bx;

class by
implements Runnable {
    final /* synthetic */ bx a;

    by(bx bx2) {
        this.a = bx2;
    }

    @Override
    public void run() {
        this.a.c();
    }
}

