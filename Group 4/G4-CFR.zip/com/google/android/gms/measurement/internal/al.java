/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

public class al {
    long a;
    long b;
    long c;
}

