/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.measurement.internal.bh;
import com.google.android.gms.measurement.internal.bx;

class ca
implements bh {
    final /* synthetic */ bx a;

    ca(bx bx2) {
        this.a = bx2;
    }

    @Override
    public void a(String string, int n2, Throwable throwable, byte[] arrby) {
        bx.a(this.a, string, n2, throwable, arrby);
    }
}

