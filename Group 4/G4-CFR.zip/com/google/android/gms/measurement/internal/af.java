/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.measurement.internal;

import com.google.android.gms.common.internal.bf;

class af {
    final String a;
    final String b;
    final long c;
    final Object d;

    af(String string, String string2, long l2, Object object) {
        bf.a(string);
        bf.a(string2);
        bf.a(object);
        this.a = string;
        this.b = string2;
        this.c = l2;
        this.d = object;
    }
}

