/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.b.ar;

final class as
extends ar {
    as() {
    }

    @Override
    public String a(String string, String string2) {
        return string2;
    }
}

