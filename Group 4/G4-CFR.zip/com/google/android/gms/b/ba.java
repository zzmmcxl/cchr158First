/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.ads.a.b;
import com.google.android.gms.b.bb;
import com.google.android.gms.b.fi;

@fi
public class ba
implements b {
    private final bb a;

    public ba(bb bb2) {
        this.a = bb2;
    }
}

