/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import android.os.IInterface;
import com.google.android.gms.b.bb;

public interface be
extends IInterface {
    public void a(bb var1);
}

