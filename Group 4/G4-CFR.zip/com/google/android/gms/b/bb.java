/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import android.os.IInterface;
import com.google.android.gms.a.a;

public interface bb
extends IInterface {
    public String a();

    public void a(a var1);

    public String b();

    public void c();

    public void d();
}

