/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.b.ar;

final class at
extends ar {
    at() {
    }

    @Override
    public String a(String string, String string2) {
        if (string == null) return string2;
        return string;
    }
}

