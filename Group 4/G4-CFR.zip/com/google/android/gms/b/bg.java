/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.ads.a.b;
import com.google.android.gms.ads.a.c;
import com.google.android.gms.b.ba;
import com.google.android.gms.b.bb;
import com.google.android.gms.b.bf;
import com.google.android.gms.b.fi;

@fi
public final class bg
extends bf {
    private final c a;

    public bg(c c2) {
        this.a = c2;
    }

    @Override
    public void a(bb bb2) {
        this.a.a(new ba(bb2));
    }
}

