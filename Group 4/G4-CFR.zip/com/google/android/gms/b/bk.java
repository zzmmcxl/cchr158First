/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.a.a;

public interface bk
extends IInterface {
    public IBinder a(a var1, a var2, a var3, int var4);
}

