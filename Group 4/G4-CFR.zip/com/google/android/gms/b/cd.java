/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.b.ce;
import com.google.android.gms.b.hb;
import java.util.Map;

final class cd
implements ce {
    cd() {
    }

    @Override
    public void a(hb hb2, Map map) {
        hb2.b("1".equals(map.get("custom_close")));
    }
}

