/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

public interface bq {
    public void a(String var1, String var2);
}

