/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import com.google.android.gms.b.fi;

@fi
public class av {
    private final long a;
    private final String b;
    private final av c;

    public av(long l2, String string, av av2) {
        this.a = l2;
        this.b = string;
        this.c = av2;
    }
}

