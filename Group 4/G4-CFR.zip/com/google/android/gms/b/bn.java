/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import android.os.IBinder;
import com.google.android.gms.a.e;
import com.google.android.gms.b.bk;
import com.google.android.gms.b.bl;
import com.google.android.gms.b.fi;

@fi
public class bn
extends e {
    public bn() {
        super("com.google.android.gms.ads.NativeAdViewDelegateCreatorImpl");
    }

    protected bk a(IBinder iBinder) {
        return bl.a(iBinder);
    }

    @Override
    protected /* synthetic */ Object b(IBinder iBinder) {
        return this.a(iBinder);
    }
}

