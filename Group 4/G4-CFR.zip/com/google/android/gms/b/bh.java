/*
 * Decompiled with CFR 0_115.
 */
package com.google.android.gms.b;

import android.net.Uri;
import android.os.IInterface;
import com.google.android.gms.a.a;

public interface bh
extends IInterface {
    public a a();

    public Uri b();

    public double c();
}

